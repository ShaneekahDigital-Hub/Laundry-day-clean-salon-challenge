Laundry Day / Learning Collection — unchanged deployment snapshot

This is a public-file archive of https://laundry-salon-demo.netlify.app/play.
index.html is the complete HTTP response from /play, saved without editing.
assets/ contains recursively discovered JavaScript and CSS dependencies.
img/ and favicon.ico contain the referenced local artwork and icon.
manifest.json records file sizes and SHA-256 checksums.

IMPORTANT: This is NOT a standalone working HTML5 or unlocked itch.io release.
The application uses Netlify server rendering, root-relative routes, purchase
verification, HttpOnly session cookies, and database-backed progress. Those
services cannot run inside an itch.io static upload. Google Fonts and Netlify
injected scripts also remain external dependencies, exactly as deployed.
The local source registers Laundry Day as a coming-soon room.

For the existing working hosted experience, open:
https://laundry-salon-demo.netlify.app/play
Use the existing purchase redemption flow for access. No installation is needed.
Do not double-click this archive's index.html or publish this archive as a
complete browser game: preserving the original bytes does not make it portable.

The companion source archive contains the editable project, not a static build.
No game design, code, or unlock rules were changed for this export.
