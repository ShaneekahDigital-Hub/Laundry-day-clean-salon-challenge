# Shaneekah Braids & Locs — The Learning Collection

An interactive children's learning adventure: a magical hallway of doors leading to rooms for Little Explorers (0–2) and Big Explorers (6–8), with synthesized sounds, a clarinet melody, rewards, and saved progress. Two paid tiers (Demo Adventure $2.98, Full Learning Collection $24.99 — separate purchases) sold via the Square store at rbvendorsconcierge.com.

**Tech:** TanStack Start (React 19), Tailwind CSS 4, Netlify Database (Drizzle ORM), Web Audio API, deployed on Netlify.

## Run locally
```bash
pnpm install
netlify dev   # or: npm run dev
```

## Configuration (environment variables)
`SQUARE_WEBHOOK_SIGNATURE_KEY`, `SQUARE_ACCESS_TOKEN`, optional `SQUARE_WEBHOOK_URL`, `SQUARE_FULL_ITEM_NAMES`, `SQUARE_DEMO_ITEM_NAMES`, `PURCHASE_WEBHOOK_SECRET`, `VITE_DEMO_CHECKOUT_URL`, `VITE_FULL_CHECKOUT_URL`.

## Roadmap
See [PLAN.md](PLAN.md): homepage, collection/grown-ups/rewards/unlock pages, Movement Magic Ladder, Big Explorers rooms, and Square go-live testing.
