# Learning Collection — Build Plan

1. ✅ Brand theme, fonts, header/footer, game world styling and animations
2. ✅ Sound engine (synthesized animals, clarinet, instruments, feedback, speech)
3. ✅ Access + progress backend (Netlify Database, Square webhook, generic webhook, receipt redeem, progress sync)
4. ✅ Game shell: mode picker, magical hallway with animated doors, room phases, celebration, certificates, break screen, grown-up settings
5. ✅ Little Explorers rooms: Color Garden, Animal Friends, Shape Parade, Sparkle Music
6. ⬜ Homepage (`src/routes/index.tsx` is still the placeholder) with brand hero, headline, CTA
7. ⬜ Pages: `/collection` (two products + separate-purchase note), `/grown-ups`, `/rewards` (stars, badges, accessories, certificates), `/unlock` (email + receipt redeem form)
8. ⬜ Movement Magic Ladder room (toddler + big versions, uses `MOVEMENTS` and Avatar `move` prop)
9. ⬜ Big Explorers rooms: Laundry Day, Music Trivia, Clean Salon, Memory Match, Pattern Castle (currently a "coming soon" placeholder in `src/components/game/rooms/index.tsx`)
10. ⬜ Square setup: real product checkout URLs, env vars, webhook subscription; end-to-end test of every door and payment flow
