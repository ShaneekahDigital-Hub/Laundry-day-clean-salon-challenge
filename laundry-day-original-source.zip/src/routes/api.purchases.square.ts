import { createHmac } from 'node:crypto'
import { createFileRoute } from '@tanstack/react-router'
import { recordPurchase, safeEqual } from '@/server/access'

const SQUARE_API = 'https://connect.squareup.com/v2'
const SQUARE_VERSION = '2025-01-23'

const names = (value: string | undefined, fallback: string[]) =>
  value
    ? value.split(',').map((s) => s.trim().toLowerCase()).filter(Boolean)
    : fallback

interface SquarePayment {
  id?: string
  status?: string
  order_id?: string
  receipt_number?: string
  buyer_email_address?: string
}

interface SquareOrder {
  line_items?: { name?: string }[]
  fulfillments?: {
    digital_details?: { recipient?: { email_address?: string } }
    shipment_details?: { recipient?: { email_address?: string } }
    pickup_details?: { recipient?: { email_address?: string } }
  }[]
}

async function fetchOrder(orderId: string, token: string) {
  const res = await fetch(`${SQUARE_API}/orders/${encodeURIComponent(orderId)}`, {
    headers: { authorization: `Bearer ${token}`, 'square-version': SQUARE_VERSION },
  })
  if (!res.ok) throw new Error(`Square order lookup failed (${res.status})`)
  const data = (await res.json()) as { order?: SquareOrder }
  return data.order ?? null
}

function tierFromOrder(order: SquareOrder): 'demo' | 'full' | null {
  const full = names(process.env.SQUARE_FULL_ITEM_NAMES, ['full learning collection'])
  const demo = names(process.env.SQUARE_DEMO_ITEM_NAMES, ['demo adventure'])
  const items = (order.line_items ?? []).map((i) => (i.name ?? '').toLowerCase())
  if (items.some((n) => full.some((f) => n.includes(f)))) return 'full'
  if (items.some((n) => demo.some((d) => n.includes(d)))) return 'demo'
  return null
}

function orderEmail(order: SquareOrder) {
  for (const f of order.fulfillments ?? []) {
    const email =
      f.digital_details?.recipient?.email_address ??
      f.shipment_details?.recipient?.email_address ??
      f.pickup_details?.recipient?.email_address
    if (email) return email
  }
  return null
}

/**
 * Square (rbvendorsconcierge.com) payment webhook. The signature is checked,
 * then the order is fetched from Square so only completed payments for the
 * Learning Collection products unlock content.
 */
export const Route = createFileRoute('/api/purchases/square')({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const signatureKey = process.env.SQUARE_WEBHOOK_SIGNATURE_KEY
        const accessToken = process.env.SQUARE_ACCESS_TOKEN
        if (!signatureKey || !accessToken)
          return Response.json({ error: 'Square is not configured' }, { status: 503 })

        const raw = await request.text()
        const notificationUrl =
          process.env.SQUARE_WEBHOOK_URL ?? `${process.env.URL ?? new URL(request.url).origin}/api/purchases/square`
        const expected = createHmac('sha256', signatureKey)
          .update(notificationUrl + raw)
          .digest('base64')
        const provided = request.headers.get('x-square-hmacsha256-signature') ?? ''
        if (!safeEqual(provided, expected))
          return Response.json({ error: 'Invalid signature' }, { status: 401 })

        let event: { type?: string; data?: { object?: { payment?: SquarePayment } } }
        try {
          event = JSON.parse(raw)
        } catch {
          return Response.json({ error: 'Invalid JSON' }, { status: 400 })
        }
        if (event.type !== 'payment.created' && event.type !== 'payment.updated')
          return Response.json({ ignored: true })

        const payment = event.data?.object?.payment
        if (!payment?.order_id || payment.status !== 'COMPLETED')
          return Response.json({ ignored: true, reason: 'Payment not completed' })

        let order: SquareOrder | null
        try {
          order = await fetchOrder(payment.order_id, accessToken)
        } catch (error) {
          console.error(error instanceof Error ? error.message : 'Square lookup failed')
          // A 5xx asks Square to retry the event later.
          return Response.json({ error: 'Order lookup failed' }, { status: 502 })
        }
        const tier = order ? tierFromOrder(order) : null
        if (!order || !tier)
          return Response.json({ ignored: true, reason: 'Not a Learning Collection order' })

        const email = payment.buyer_email_address ?? orderEmail(order)
        if (!email) {
          console.error(`Square order ${payment.order_id} has no buyer email`)
          return Response.json({ ignored: true, reason: 'No buyer email' })
        }
        await recordPurchase({
          orderRef: payment.order_id,
          receiptRef: payment.receipt_number,
          email,
          tier,
        })
        return Response.json({ recorded: true, tier })
      },
    },
  },
})
