import { Link, createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Clock, Footprints, ShieldCheck, Volume2 } from 'lucide-react'
import { SiteLayout } from '@/components/site/SiteLayout'
import { GrownUpGate } from '@/components/game/GrownUpGate'
import { SettingsPanel } from '@/components/game/SettingsPanel'
import { CREDIT_NOTE } from '@/lib/products'

export const Route = createFileRoute('/grown-ups')({
  head: () => ({
    meta: [{ title: 'For Grown-Ups | Shaneekah Braids & Locs' }],
  }),
  component: GrownUpsPage,
})

const NOTES = [
  {
    icon: ShieldCheck,
    title: 'Gentle for little ones',
    text: 'Little Explorers (ages 0–2) is meant to be played with a grown-up. It has large, calm objects, no flashing, and no wrong-answer penalties.',
  },
  {
    icon: Footprints,
    title: 'Optional, supervised movement',
    text: 'The Movement Magic Ladder suggests safe moves in an open space. You can switch it off at any time.',
  },
  {
    icon: Volume2,
    title: 'Sound you control',
    text: 'Adjust the volume, or mute music, voice, and sound effects separately.',
  },
  {
    icon: Clock,
    title: 'Play-time breaks',
    text: 'Set a gentle reminder to stop for the day. Stars and progress are always saved.',
  },
]

function GrownUpsPage() {
  const [unlocked, setUnlocked] = useState(false)
  return (
    <SiteLayout>
      <div className="mx-auto max-w-content px-4 py-12 sm:px-6">
        <p className="text-center font-script text-3xl text-rose">
          for grown-ups
        </p>
        <h1 className="text-center font-display text-4xl font-semibold">
          Playing together, safely
        </h1>
        <p className="mx-auto mt-3 max-w-reading text-center text-muted-foreground">
          The Learning Collection is built for curious kids and the grown-ups
          beside them. Here’s how it keeps play calm, safe, and in your control.
        </p>
        <ul className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {NOTES.map(({ icon: Icon, title, text }) => (
            <li
              key={title}
              className="rounded-xl border border-border bg-card p-6"
            >
              <Icon aria-hidden className="size-6 text-rose" />
              <h2 className="mt-3 font-display text-lg font-semibold">
                {title}
              </h2>
              <p className="mt-2 text-sm text-muted-foreground">{text}</p>
            </li>
          ))}
        </ul>
        <section
          aria-labelledby="settings-title"
          className="mx-auto mt-12 max-w-xl rounded-2xl border border-border bg-card p-6"
        >
          <h2
            id="settings-title"
            className="font-display text-2xl font-semibold"
          >
            Game settings
          </h2>
          <div className="mt-4">
            {unlocked ? (
              <SettingsPanel />
            ) : (
              <GrownUpGate onPass={() => setUnlocked(true)} />
            )}
          </div>
        </section>
        <section
          aria-labelledby="buying-title"
          className="mx-auto mt-12 max-w-reading text-center"
        >
          <h2 id="buying-title" className="font-display text-2xl font-semibold">
            Purchases &amp; access
          </h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Checkout happens at rbvendorsconcierge.com. After paying, enter your
            email and the order or receipt number on the{' '}
            <Link to="/unlock" className="font-semibold text-rose underline">
              unlock page
            </Link>
            . {CREDIT_NOTE}{' '}
            <Link
              to="/collection"
              className="font-semibold text-rose underline"
            >
              Compare what’s included
            </Link>
            .
          </p>
        </section>
      </div>
    </SiteLayout>
  )
}
