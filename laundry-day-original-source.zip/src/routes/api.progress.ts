import { createFileRoute } from '@tanstack/react-router'
import { progressSchema } from '@/lib/progress'
import { saveProgress, sessionEmail } from '@/server/access'

export const Route = createFileRoute('/api/progress')({
  server: {
    handlers: {
      PUT: async ({ request }) => {
        const email = await sessionEmail(request)
        if (!email) return Response.json({ error: 'Not signed in' }, { status: 401 })
        const text = await request.text()
        if (text.length > 20_000)
          return Response.json({ error: 'Progress is too large' }, { status: 413 })
        let body: unknown
        try {
          body = JSON.parse(text)
        } catch {
          return Response.json({ error: 'Invalid JSON' }, { status: 400 })
        }
        const parsed = progressSchema.safeParse(body)
        if (!parsed.success)
          return Response.json({ error: 'Invalid progress' }, { status: 400 })
        const progress = await saveProgress(email, parsed.data)
        return Response.json({ progress })
      },
    },
  },
})
