import { createFileRoute } from '@tanstack/react-router'
import {
  clearedCookie,
  endSession,
  loadProgress,
  maskEmail,
  sessionEmail,
  tierForEmail,
} from '@/server/access'

export const Route = createFileRoute('/api/access')({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const email = await sessionEmail(request)
        if (!email) return Response.json({ tier: 'none' })
        const [tier, progress] = await Promise.all([
          tierForEmail(email),
          loadProgress(email),
        ])
        return Response.json({ tier, email: maskEmail(email), progress })
      },
      DELETE: async ({ request }) => {
        await endSession(request)
        return new Response(null, {
          status: 204,
          headers: { 'set-cookie': clearedCookie },
        })
      },
    },
  },
})
