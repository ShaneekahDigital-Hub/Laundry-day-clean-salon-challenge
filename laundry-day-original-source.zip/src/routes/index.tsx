import { Link, createFileRoute } from '@tanstack/react-router'
import {
  ArrowRight,
  Check,
  Footprints,
  Music,
  Shirt,
  Sparkles,
  Star,
} from 'lucide-react'
import { SiteLayout } from '@/components/site/SiteLayout'
import { Badge } from '@/components/ui/badge'
import { CREDIT_NOTE, PRODUCTS } from '@/lib/products'

export const Route = createFileRoute('/')({
  component: Home,
})

// Served through Netlify Image CDN so the large source PNG is resized and compressed.
const heroSrc = (w: number) =>
  `/.netlify/images?url=/img/salon-adventure.png&w=${w}&fm=webp&q=80`

const DISCOVER = [
  {
    icon: Sparkles,
    title: 'Hair care',
    text: 'Brushes, combs, and a clean salon to inspect.',
  },
  {
    icon: Shirt,
    title: 'Laundry love',
    text: 'Sort, wash, and fold like a pro.',
  },
  {
    icon: Music,
    title: 'Music',
    text: 'Clarinet songs and instrument trivia.',
  },
  {
    icon: Footprints,
    title: 'Movement',
    text: 'Wiggle, hop, and scoot on the Magic Ladder.',
  },
  {
    icon: Star,
    title: 'Colors & shapes',
    text: 'Balloons, hearts, stars, and sparkly surprises.',
  },
]

const btnPrimary =
  'inline-flex items-center justify-center gap-2 rounded-lg bg-primary px-6 py-3 font-semibold text-primary-foreground transition-colors hover:bg-rose-deep focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:outline-none motion-reduce:transition-none'
const btnOutline =
  'inline-flex items-center justify-center gap-2 rounded-lg border border-input bg-background px-6 py-3 font-semibold transition-colors hover:bg-muted focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none motion-reduce:transition-none'

function Home() {
  return (
    <SiteLayout>
      {/* Hero */}
      <section className="bg-linear-to-b from-secondary/50 to-background">
        <div className="mx-auto grid max-w-content items-center gap-10 px-4 py-12 sm:px-6 md:py-16 lg:grid-cols-[1fr_1.15fr]">
          <div className="text-center lg:text-left">
            <p className="font-script text-3xl text-rose">
              welcome, little explorer
            </p>
            <h1 className="mt-1 font-display text-4xl leading-tight font-semibold sm:text-5xl lg:text-6xl">
              Good Habits. Great Hair. Let’s Play!
            </h1>
            <p className="mx-auto mt-5 max-w-reading text-lg text-muted-foreground lg:mx-0">
              Big adventures for little learners! Discover hair care, laundry
              love, music, movement, colors, shapes, and sparkling surprises.
              Every little adventure brings something new to discover.
            </p>
            <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row sm:justify-center lg:justify-start">
              <Link to="/play" className={`${btnPrimary} text-lg`}>
                Let’s Start Learning!
                <ArrowRight aria-hidden className="size-5" />
              </Link>
              <Link to="/collection" className={btnOutline}>
                See Our Collection
              </Link>
            </div>
            <p className="mt-4 text-sm text-muted-foreground">
              Little Explorers (ages 0–2) · Big Explorers (ages 6–8)
            </p>
          </div>
          <figure className="relative">
            <img
              src={heroSrc(1000)}
              srcSet={`${heroSrc(640)} 640w, ${heroSrc(1000)} 1000w, ${heroSrc(1400)} 1400w`}
              sizes="(min-width: 1024px) 640px, 100vw"
              width={1264}
              height={848}
              alt="An illustrated girl with braids holding folded towels in a cozy pink room with a salon station, washing machine, and laundry baskets."
              className="aspect-[1264/848] w-full rounded-[2rem] border-4 border-card object-cover shadow-xl"
              fetchPriority="high"
            />
            <span
              aria-hidden
              className="absolute -top-4 -right-2 rotate-6 rounded-full bg-butter px-4 py-2 font-game text-sm font-bold text-accent-foreground shadow"
            >
              ✨ Tap, listen &amp; play!
            </span>
          </figure>
        </div>
      </section>

      {/* What children discover */}
      <section
        aria-labelledby="discover-title"
        className="mx-auto max-w-content px-4 py-12 sm:px-6"
      >
        <h2
          id="discover-title"
          className="text-center font-display text-3xl font-semibold"
        >
          A magical hallway full of doors
        </h2>
        <p className="mx-auto mt-2 max-w-reading text-center text-muted-foreground">
          Every door opens into a colorful room where objects respond to touch,
          animals say hello, and each finished challenge earns stars, badges,
          and new rewards.
        </p>
        <ul className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {DISCOVER.map(({ icon: Icon, title, text }) => (
            <li
              key={title}
              className="rounded-xl border border-border bg-card p-5 text-center"
            >
              <span className="mx-auto flex size-11 items-center justify-center rounded-full bg-secondary text-rose">
                <Icon aria-hidden className="size-5" />
              </span>
              <h3 className="mt-3 font-semibold">{title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{text}</p>
            </li>
          ))}
        </ul>
      </section>

      {/* Pricing */}
      <section aria-labelledby="pricing-title" className="bg-linen">
        <div className="mx-auto max-w-content px-4 py-12 sm:px-6">
          <h2
            id="pricing-title"
            className="text-center font-display text-3xl font-semibold"
          >
            Two ways to play
          </h2>
          <div className="mx-auto mt-8 grid max-w-4xl gap-6 md:grid-cols-2">
            {(['demo', 'full'] as const).map((key) => {
              const p = PRODUCTS[key]
              const featured = key === 'full'
              return (
                <article
                  key={key}
                  aria-labelledby={`home-${key}-title`}
                  className={`flex flex-col rounded-2xl border bg-card p-6 ${featured ? 'border-rose shadow-lg' : 'border-border'}`}
                >
                  <div className="flex items-center justify-between gap-4">
                    <p className="text-xs font-bold tracking-[1.5px] text-rose uppercase">
                      {p.kicker}
                    </p>
                    {featured && <Badge>Best value</Badge>}
                  </div>
                  <h3
                    id={`home-${key}-title`}
                    className="mt-2 font-display text-2xl font-semibold"
                  >
                    {p.name}
                  </h3>
                  <p className="mt-1 font-display text-4xl font-semibold">
                    {p.price}
                  </p>
                  <p className="mt-3 text-sm text-muted-foreground">
                    {p.blurb}
                  </p>
                  <ul className="mt-4 mb-6 space-y-2 text-sm">
                    {p.includes.map((i) => (
                      <li key={i} className="flex gap-2">
                        <Check
                          aria-hidden
                          className="mt-0.5 size-4 shrink-0 text-rose"
                        />
                        {i}
                      </li>
                    ))}
                  </ul>
                  <Link
                    to="/collection"
                    className={`mt-auto ${featured ? btnPrimary : btnOutline}`}
                  >
                    See what’s included
                  </Link>
                </article>
              )
            })}
          </div>
          <p className="mx-auto mt-6 max-w-reading text-center text-sm text-muted-foreground">
            {CREDIT_NOTE}{' '}
            <Link
              to="/unlock"
              className="font-semibold text-rose underline underline-offset-4"
            >
              Already purchased? Unlock here.
            </Link>
          </p>
        </div>
      </section>

      {/* Closing CTA */}
      <section className="mx-auto max-w-content px-4 py-12 text-center sm:px-6">
        <p className="font-display text-2xl font-semibold sm:text-3xl">
          Little lessons. Big confidence. A whole lot of sparkle.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Link to="/play" className={btnPrimary}>
            Let’s Start Learning!
          </Link>
          <Link to="/grown-ups" className={btnOutline}>
            For Grown-Ups
          </Link>
        </div>
      </section>
    </SiteLayout>
  )
}
