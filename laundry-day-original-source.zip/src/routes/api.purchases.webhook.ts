import { createFileRoute } from '@tanstack/react-router'
import { z } from 'zod'
import { normalizeOrder, recordPurchase, safeEqual } from '@/server/access'

const PAID_STATUSES = ['paid', 'completed', 'complete', 'succeeded', 'success', 'processing']

const payload = z.object({
  orderId: z.union([z.string(), z.number()]).transform(String),
  receiptNumber: z.string().max(80).optional(),
  email: z.email().max(200),
  product: z.string().max(200).optional(),
  amount: z.union([z.number(), z.string()]).optional(),
  status: z.string().max(40).optional(),
})

function resolveTier(product?: string, amount?: number | string) {
  const p = product?.toLowerCase() ?? ''
  if (p.includes('full') || p.includes('collection')) return 'full'
  if (p.includes('demo')) return 'demo'
  const value = Number(String(amount ?? '').replace(/[^0-9.]/g, ''))
  if (Math.abs(value - 24.99) < 0.005) return 'full'
  if (Math.abs(value - 2.98) < 0.005) return 'demo'
  return null
}

/**
 * Generic order confirmation (for Zapier-style automations or manual entry).
 * Square sends its own signed events to /api/purchases/square instead.
 */
export const Route = createFileRoute('/api/purchases/webhook')({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const secret = process.env.PURCHASE_WEBHOOK_SECRET
        if (!secret)
          return Response.json({ error: 'Webhook is not configured' }, { status: 503 })
        const provided =
          request.headers.get('authorization')?.replace(/^Bearer\s+/i, '') ??
          request.headers.get('x-webhook-secret') ??
          ''
        if (!safeEqual(provided, secret))
          return Response.json({ error: 'Unauthorized' }, { status: 401 })

        let body: unknown
        try {
          body = await request.json()
        } catch {
          return Response.json({ error: 'Invalid JSON' }, { status: 400 })
        }
        const parsed = payload.safeParse(body)
        if (!parsed.success)
          return Response.json({ error: 'orderId and email are required' }, { status: 400 })

        const { orderId, receiptNumber, email, product, amount, status } =
          parsed.data
        if (status && !PAID_STATUSES.includes(status.toLowerCase()))
          return Response.json({ ignored: true, reason: 'Order is not paid' }, { status: 202 })

        const tier = resolveTier(product, amount)
        if (!tier)
          return Response.json({ error: 'Unknown product' }, { status: 422 })

        const orderRef = normalizeOrder(orderId)
        if (!orderRef) return Response.json({ error: 'orderId is required' }, { status: 400 })
        await recordPurchase({ orderRef, receiptRef: receiptNumber, email, tier })
        return Response.json({ recorded: true, orderId: orderRef, tier })
      },
    },
  },
})
