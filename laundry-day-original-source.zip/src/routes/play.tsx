import { Link, Outlet, createFileRoute, useParams } from '@tanstack/react-router'
import { useEffect, useState } from 'react'
import { DoorOpen, Home, Settings2, Star, Volume2, VolumeX } from 'lucide-react'
import { useGame } from '@/components/game/GameProvider'
import { SparkleTrail } from '@/components/game/Particles'
import { BreakScreen } from '@/components/game/BreakScreen'
import { GrownUpGate } from '@/components/game/GrownUpGate'
import { SettingsPanel } from '@/components/game/SettingsPanel'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'

export const Route = createFileRoute('/play')({
  head: () => ({ meta: [{ title: 'Learn & Play | Shaneekah Braids & Locs' }] }),
  component: PlayLayout,
})

const iconBtn =
  'chunky-btn flex size-12 items-center justify-center bg-white/90 text-g-purple focus-visible:ring-4 focus-visible:ring-g-yellow focus-visible:outline-none sm:size-14'

function PlayLayout() {
  const { settings, updateSettings, stars, setPlaying, breakDue, access } = useGame()
  const params = useParams({ strict: false }) as { mode?: string; roomId?: string }
  const mode = params.mode === 'little' ? 'little' : params.mode === 'big' ? 'big' : null
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [unlocked, setUnlocked] = useState(false)

  useEffect(() => {
    setPlaying(true)
    return () => setPlaying(false)
  }, [setPlaying])

  return (
    <div className={`game-world relative overflow-x-hidden ${mode === 'little' ? 'mode-little' : ''}`}>
      <SparkleTrail enabled={!settings.calmMotion && mode !== 'little'} />
      <header className="relative z-30 mx-auto flex max-w-6xl items-center gap-2 px-3 pt-3 sm:gap-3 sm:px-6 sm:pt-5">
        <Link to="/" className={iconBtn} aria-label="Back to home page">
          <Home aria-hidden className="size-6" />
        </Link>
        {mode && params.roomId && (
          <Link to="/play/$mode" params={{ mode }} className={iconBtn} aria-label="Back to the magical hallway">
            <DoorOpen aria-hidden className="size-6" />
          </Link>
        )}
        <Link
          to="/rewards"
          className="chunky-btn ml-auto flex h-12 items-center gap-2 bg-white/90 px-4 text-lg text-g-ink sm:h-14"
          aria-label={`My rewards: ${stars} stars`}
        >
          <Star aria-hidden className="size-6 fill-g-yellow text-[#e0a800]" />
          <span className="tabular-nums">{stars}</span>
        </Link>
        <button
          type="button"
          className={iconBtn}
          onClick={() => updateSettings({ muted: !settings.muted })}
          aria-pressed={settings.muted}
          aria-label={settings.muted ? 'Turn sound on' : 'Mute sound'}
        >
          {settings.muted ? <VolumeX aria-hidden className="size-6" /> : <Volume2 aria-hidden className="size-6" />}
        </button>
        <button
          type="button"
          className={iconBtn}
          onClick={() => {
            setUnlocked(false)
            setSettingsOpen(true)
          }}
          aria-label="Grown-up settings"
        >
          <Settings2 aria-hidden className="size-6" />
        </button>
      </header>

      <Outlet />

      {access.status === 'ready' && access.tier !== 'none' && (
        <p className="sr-only" role="status">
          {access.tier === 'full' ? 'Full Learning Collection unlocked' : 'Demo Adventure unlocked'}
        </p>
      )}

      <Dialog open={settingsOpen} onOpenChange={setSettingsOpen}>
        <DialogContent className="max-h-[90dvh] overflow-y-auto bg-background">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl">Grown-up settings</DialogTitle>
            <DialogDescription>Sound, movement, motion, and play time controls.</DialogDescription>
          </DialogHeader>
          {unlocked ? <SettingsPanel /> : <GrownUpGate onPass={() => setUnlocked(true)} />}
        </DialogContent>
      </Dialog>

      {breakDue && <BreakScreen />}
    </div>
  )
}
