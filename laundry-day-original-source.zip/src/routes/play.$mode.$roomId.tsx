import { Link, createFileRoute, notFound } from '@tanstack/react-router'
import { useEffect, useState } from 'react'
import { Lock } from 'lucide-react'
import { Avatar } from '@/components/game/Avatar'
import { Celebration } from '@/components/game/Celebration'
import { useGame } from '@/components/game/GameProvider'
import type { CompletionResult } from '@/components/game/GameProvider'
import { useParticles } from '@/components/game/Particles'
import { UnlockButton } from '@/components/game/UpgradeInvite'
import { ROOM_COMPONENTS } from '@/components/game/rooms'
import { StepPills } from '@/components/game/rooms/StepPills'
import { doorState, getRoom } from '@/lib/game-data'
import { sound } from '@/lib/audio'

export const Route = createFileRoute('/play/$mode/$roomId')({
  beforeLoad: ({ params }) => {
    const room = getRoom(params.roomId)
    if (!room || room.mode !== params.mode) throw notFound()
  },
  head: ({ params }) => ({
    meta: [{ title: `${getRoom(params.roomId)?.title ?? 'Room'} | Learn & Play` }],
  }),
  component: RoomPage,
})

type Phase = 'intro' | 'play' | 'done'

function RoomPage() {
  const { roomId } = Route.useParams()
  const room = getRoom(roomId)!
  const { access, progress, settings, completeRoom, hydrated } = useGame()
  const gentle = room.mode === 'little'
  const { burst, layer } = useParticles(gentle)
  const [phase, setPhase] = useState<Phase>('intro')
  const [result, setResult] = useState<CompletionResult | null>(null)
  const [round, setRound] = useState(0)

  useEffect(() => {
    setPhase('intro')
    setResult(null)
    return () => {
      sound.stopSpeech()
      sound.stopMusic()
    }
  }, [roomId])

  const state = doorState(room, access.tier, progress, settings.movement)

  if (!hydrated || access.status === 'loading') {
    return (
      <div className="mx-auto mt-16 flex max-w-md flex-col items-center gap-4 text-center">
        <div className="size-24 animate-pulse rounded-full bg-white/60 motion-reduce:animate-none" />
        <p className="text-xl font-bold text-white">Opening the door…</p>
      </div>
    )
  }

  if (state !== 'open' && phase !== 'done') {
    return (
      <main className="mx-auto mt-10 max-w-md px-4">
        <div className="game-card p-6 text-center">
          <Lock aria-hidden className="mx-auto size-10 text-g-purple" />
          <h1 className="mt-2 text-3xl font-bold text-g-purple">{room.title} is locked</h1>
          <p className="mt-2 text-lg">
            {state === 'locked-stars'
              ? `Collect ${room.unlockStars} stars in this hallway to open this secret door.`
              : state === 'hidden-movement'
                ? 'A grown-up has turned movement activities off in settings.'
                : 'This door opens with the Full Learning Collection.'}
          </p>
          <div className="mt-5 flex flex-col items-center gap-3">
            {state === 'locked-tier' && <UnlockButton />}
            <Link to="/play/$mode" params={{ mode: room.mode }} className="font-semibold text-g-purple underline underline-offset-4">
              Back to the hallway
            </Link>
          </div>
        </div>
      </main>
    )
  }

  const RoomComponent = ROOM_COMPONENTS[room.id]

  return (
    <main className="relative mx-auto max-w-5xl px-3 pt-4 pb-16 sm:px-6">
      {layer}
      {phase === 'intro' && (
        <section className="anim-room-enter mx-auto max-w-xl">
          <StepPills current="Begin" />
          <div
            className="mt-4 overflow-hidden rounded-[2rem] p-6 text-center shadow-2xl sm:p-8"
            style={{ background: `linear-gradient(160deg, ${room.to}, ${room.from})` }}
          >
            <p aria-hidden className="anim-twirl-in text-7xl">{room.icon}</p>
            <h1 className="mt-2 text-4xl font-bold text-white drop-shadow-[0_3px_0_#0003] sm:text-5xl">{room.title}</h1>
            <div className="mt-5 flex items-end justify-center gap-3">
              <Avatar size={90} className="shrink-0" />
              <p className="game-card mb-3 px-4 py-3 text-left text-lg font-semibold">{room.intro}</p>
            </div>
            {room.movement && (
              <p className="mx-auto mt-4 max-w-md rounded-2xl bg-white/85 px-4 py-2 text-sm font-semibold text-g-ink">
                🧑‍🍼 Grown-up supervision needed. Clear a safe, open space. Every move is optional — skip any move at any time.
              </p>
            )}
            {gentle && !room.movement && (
              <p className="mx-auto mt-4 max-w-md rounded-2xl bg-white/85 px-4 py-2 text-sm font-semibold text-g-ink">
                🧑‍🍼 For grown-ups: sit together and guide little hands. There are no wrong taps here.
              </p>
            )}
            <button
              type="button"
              autoFocus
              onClick={() => {
                sound.pop()
                sound.say(room.intro)
                setPhase('play')
              }}
              className="chunky-btn mt-6 bg-white px-10 py-4 text-2xl text-g-purple focus-visible:ring-4 focus-visible:ring-g-yellow focus-visible:outline-none"
            >
              Let’s go! ✨
            </button>
          </div>
        </section>
      )}
      {phase === 'play' && (
        <div className="anim-room-enter">
          <RoomComponent
            key={round}
            demo={access.tier === 'demo'}
            gentle={gentle}
            burst={burst}
            onComplete={(stars) => {
              setResult(completeRoom(room.id, stars))
              setPhase('done')
              window.scrollTo({ top: 0, behavior: 'smooth' })
            }}
          />
        </div>
      )}
      {phase === 'done' && result && (
        <>
          <StepPills current="Finish" />
          <Celebration
            room={room}
            result={result}
            onReplay={() => {
              setRound((r) => r + 1)
              setPhase('play')
            }}
          />
        </>
      )}
    </main>
  )
}
