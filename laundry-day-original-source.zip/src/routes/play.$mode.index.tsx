import { createFileRoute, notFound, useNavigate } from '@tanstack/react-router'
import { useEffect, useState } from 'react'
import { Check, Lock, Star } from 'lucide-react'
import { Avatar } from '@/components/game/Avatar'
import { useGame } from '@/components/game/GameProvider'
import { UnlockButton, UpgradeInvite } from '@/components/game/UpgradeInvite'
import {
  MODES,
  demoFinished,
  doorState,
  modeStars,
  roomsFor,
} from '@/lib/game-data'
import type { DoorState, Mode, Room } from '@/lib/game-data'
import { sound } from '@/lib/audio'

export const Route = createFileRoute('/play/$mode/')({
  beforeLoad: ({ params }) => {
    if (params.mode !== 'little' && params.mode !== 'big') throw notFound()
  },
  component: Hallway,
})

function Hallway() {
  const { mode: raw } = Route.useParams()
  const mode = raw as Mode
  const navigate = useNavigate()
  const { access, progress, settings } = useGame()
  const [opening, setOpening] = useState<string | null>(null)
  const [wiggle, setWiggle] = useState<string | null>(null)
  const info = MODES[mode]
  const greeting =
    mode === 'little'
      ? 'Hi friend! Grown-ups, tap a door together and we’ll explore.'
      : 'Welcome, Big Explorer! Pick a door and take on the challenge.'
  const [bubble, setBubble] = useState(greeting)

  useEffect(() => setBubble(greeting), [greeting])

  const rooms = roomsFor(mode)
  const tier = access.tier
  const stars = modeStars(progress, mode)

  const choose = (room: Room, state: DoorState) => {
    if (opening) return
    if (state === 'open') {
      setOpening(room.id)
      sound.doorOpen()
      sound.say(room.title)
      window.setTimeout(
        () => navigate({ to: '/play/$mode/$roomId', params: { mode, roomId: room.id } }),
        settings.calmMotion ? 500 : 1000,
      )
      return
    }
    sound.gentleNo()
    setWiggle(room.id)
    window.setTimeout(() => setWiggle(null), 650)
    const msg =
      state === 'locked-stars'
        ? `This secret door opens when you collect ${room.unlockStars} stars in ${info.title}. You have ${stars}!`
        : tier === 'none'
          ? 'This door is locked. Ask a grown-up to unlock the adventure!'
          : 'This door opens with the Full Learning Collection.'
    setBubble(msg)
    sound.say(msg)
  }

  const showInvite = tier === 'demo' && demoFinished(progress, mode, settings.movement)
  const anyTierLocked = rooms.some((r) => doorState(r, tier, progress, settings.movement) === 'locked-tier')

  return (
    <main className="relative mx-auto max-w-6xl px-3 pt-4 pb-16 sm:px-6">
      <h1 className="sr-only">
        {info.title} magical hallway
      </h1>
      <div className="flex items-end justify-center gap-3 sm:gap-5">
        <Avatar size={96} className="anim-float shrink-0" />
        <p
          role="status"
          aria-live="polite"
          className="game-card relative mb-6 max-w-md px-5 py-3 text-lg font-semibold sm:text-xl"
        >
          {bubble}
          <span aria-hidden className="absolute -left-2 bottom-4 size-4 rotate-45 bg-white" />
        </p>
      </div>

      <section
        aria-label="Doors"
        className="relative mt-2 overflow-hidden rounded-[2.5rem] border-[6px] border-white/70 px-3 pt-8 pb-10 shadow-2xl sm:px-6"
        style={{
          background:
            mode === 'little'
              ? 'repeating-linear-gradient(90deg, #fff3fa 0 28px, #ffe3f1 28px 56px)'
              : 'repeating-linear-gradient(90deg, #4a1d9e 0 30px, #5a27b5 30px 60px)',
        }}
      >
        {/* hanging stars */}
        <div aria-hidden className="pointer-events-none absolute inset-x-0 top-0 flex justify-around">
          {['#ffd23f', '#ff5fa2', '#2ed47a', '#3ec5ff', '#ffd23f'].map((c, i) => (
            <span key={i} className="flex flex-col items-center">
              <span className="h-6 w-px bg-white/60" />
              <span className="anim-twinkle text-2xl" style={{ color: c, animationDelay: `${i * 0.4}s` }}>★</span>
            </span>
          ))}
        </div>
        {/* floor */}
        <div
          aria-hidden
          className="pointer-events-none absolute inset-x-0 bottom-0 h-20"
          style={{
            background:
              mode === 'little'
                ? 'linear-gradient(180deg, #ffd6a8, #ffc38a)'
                : 'linear-gradient(180deg, #ff8fc0, #ff5fa2)',
            clipPath: 'polygon(4% 0, 96% 0, 100% 100%, 0 100%)',
          }}
        />
        <ul className="relative flex flex-wrap items-end justify-center gap-x-4 gap-y-8 sm:gap-x-6">
          {rooms.map((room) => {
            const state = doorState(room, tier, progress, settings.movement)
            if (state === 'hidden-movement') return null
            return (
              <li key={room.id}>
                <Door
                  room={room}
                  state={state}
                  open={opening === room.id}
                  wiggle={wiggle === room.id}
                  stars={progress.rooms[room.id]?.stars ?? 0}
                  onChoose={() => choose(room, state)}
                />
              </li>
            )
          })}
        </ul>
      </section>

      <p className="mt-4 text-center font-semibold text-white drop-shadow">
        ⭐ {stars} stars collected in {info.title}
      </p>

      {showInvite ? (
        <div className="mx-auto mt-8 max-w-2xl">
          <UpgradeInvite />
        </div>
      ) : (
        tier === 'demo' &&
        anyTierLocked && (
          <div className="mt-6 flex justify-center">
            <UnlockButton>Unlock every door</UnlockButton>
          </div>
        )
      )}
    </main>
  )
}

function Door({
  room,
  state,
  open,
  wiggle,
  stars,
  onChoose,
}: {
  room: Room
  state: DoorState
  open: boolean
  wiggle: boolean
  stars: number
  onChoose: () => void
}) {
  const locked = state !== 'open'
  const label = `${room.title}. ${room.tagline}. ${
    state === 'open'
      ? stars
        ? `Completed with ${stars} of 3 stars.`
        : 'Tap to open.'
      : state === 'locked-stars'
        ? `Secret door, needs ${room.unlockStars} stars.`
        : 'Locked.'
  }`
  return (
    <button
      type="button"
      onClick={onChoose}
      aria-label={label}
      className={`door-frame group relative block h-[220px] w-[140px] rounded-t-[70px] text-left focus-visible:outline-none sm:h-[250px] sm:w-[160px] ${wiggle ? 'anim-wiggle' : ''}`}
      data-open={open}
    >
      {/* the room glowing behind the door */}
      <span
        aria-hidden
        className="absolute inset-0 flex items-center justify-center rounded-t-[70px] text-6xl"
        style={{
          background: `radial-gradient(circle at 50% 40%, #fff 0%, ${room.to} 45%, ${room.from} 100%)`,
        }}
      >
        <span className={open ? 'anim-twirl-in' : 'opacity-0'}>{room.icon}</span>
      </span>
      {/* door panel */}
      <span
        aria-hidden
        className={`door-panel absolute inset-0 flex flex-col items-center rounded-t-[70px] border-[5px] border-white/80 px-3 pt-6 pb-3 shadow-lg transition-[filter] group-hover:brightness-110 group-focus-visible:ring-4 group-focus-visible:ring-g-yellow ${!locked && !stars ? 'anim-door-glow' : ''}`}
        style={{
          background: `linear-gradient(160deg, ${room.to}, ${room.from})`,
          filter: locked ? 'saturate(0.55)' : undefined,
        }}
      >
        <span className="flex size-16 items-center justify-center rounded-full bg-white/85 text-4xl shadow-inner sm:size-[72px]">
          {state === 'locked-tier' ? '🔒' : state === 'locked-stars' ? '🗝️' : room.icon}
        </span>
        <span className="mt-3 rounded-xl bg-white/90 px-2 py-1 text-center text-[13px] leading-tight font-bold text-g-ink sm:text-sm">
          {room.title}
        </span>
        <span className="mt-auto flex gap-0.5">
          {[1, 2, 3].map((n) => (
            <Star
              key={n}
              className={`size-5 ${n <= stars ? 'fill-g-yellow text-[#e0a800]' : 'fill-white/40 text-white/70'}`}
            />
          ))}
        </span>
        {/* knob */}
        <span className="absolute top-1/2 right-3 size-3.5 rounded-full bg-g-yellow shadow" />
        {stars > 0 && (
          <span className="absolute -top-1 -right-1 flex size-8 items-center justify-center rounded-full bg-g-green text-white shadow">
            <Check className="size-5" strokeWidth={3} />
          </span>
        )}
        {locked && (
          <span className="absolute -top-1 -right-1 flex items-center gap-1 rounded-full bg-g-ink px-2 py-1 text-[11px] font-bold text-white shadow">
            <Lock className="size-3" />
            {state === 'locked-stars' ? `${room.unlockStars}★` : room.demo ? 'Unlock' : 'Full'}
          </span>
        )}
        {room.demo && !locked && (
          <span className="absolute -top-1 -left-1 rounded-full bg-white px-2 py-0.5 text-[10px] font-bold text-g-purple shadow">
            DEMO
          </span>
        )}
      </span>
    </button>
  )
}
