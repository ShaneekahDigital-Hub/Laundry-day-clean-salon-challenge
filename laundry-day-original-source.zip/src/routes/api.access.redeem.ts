import { createFileRoute } from '@tanstack/react-router'
import { and, eq, or } from 'drizzle-orm'
import { z } from 'zod'
import { db } from '../../db/index.js'
import { purchases } from '../../db/schema.js'
import {
  createSession,
  loadProgress,
  maskEmail,
  normalizeEmail,
  normalizeOrder,
  sessionCookie,
  tierForEmail,
} from '@/server/access'

const input = z.object({
  email: z.email().max(200),
  orderId: z.string().trim().min(1).max(80),
})

export const Route = createFileRoute('/api/access/redeem')({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: unknown
        try {
          body = await request.json()
        } catch {
          return Response.json({ error: 'Invalid request' }, { status: 400 })
        }
        const parsed = input.safeParse(body)
        if (!parsed.success)
          return Response.json(
            { error: 'Please enter the email and order number from your receipt.' },
            { status: 400 },
          )
        const email = normalizeEmail(parsed.data.email)
        const ref = normalizeOrder(parsed.data.orderId)
        const [match] = await db
          .select({ id: purchases.id })
          .from(purchases)
          .where(
            and(
              eq(purchases.email, email),
              or(
                eq(purchases.orderRef, ref),
                eq(purchases.receiptRef, ref),
              ),
            ),
          )
          .limit(1)
        if (!match)
          return Response.json(
            {
              error:
                'We couldn’t find a paid order with that email and order number yet. Payments can take a minute to confirm — please try again shortly.',
            },
            { status: 404 },
          )
        const token = await createSession(email)
        const [tier, progress] = await Promise.all([
          tierForEmail(email),
          loadProgress(email),
        ])
        return Response.json(
          { tier, email: maskEmail(email), progress },
          { headers: { 'set-cookie': sessionCookie(token) } },
        )
      },
    },
  },
})
