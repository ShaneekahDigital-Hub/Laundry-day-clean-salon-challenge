import { Link, createFileRoute } from '@tanstack/react-router'
import {
  Check,
  DoorOpen,
  ExternalLink,
  Footprints,
  HeartHandshake,
  Info,
  Minus,
  Music,
  ShieldCheck,
  Sparkles,
  Star,
} from 'lucide-react'
import { SiteLayout } from '@/components/site/SiteLayout'
import { Badge } from '@/components/ui/badge'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { MODES, roomsFor } from '@/lib/game-data'
import type { Mode } from '@/lib/game-data'
import { CREDIT_NOTE, EVERY_PURCHASE, PRODUCTS } from '@/lib/products'

export const Route = createFileRoute('/collection')({
  head: () => ({
    meta: [
      { title: 'Our Collection | Shaneekah Braids & Locs' },
      {
        name: 'description',
        content:
          'What’s inside the Learning Collection: the $2.98 Demo Adventure and the $24.99 Full Learning Collection, room by room.',
      },
    ],
  }),
  component: CollectionPage,
})

const HIGHLIGHTS = [
  {
    icon: DoorOpen,
    title: 'Magical doors & rooms',
    text: 'A hallway of animated doors, each opening into an illustrated room with touch-responsive objects that turn into hearts, stars, circles, and blocks.',
  },
  {
    icon: Music,
    title: 'Sound & music',
    text: 'Cats meow, dogs bark, stars sparkle, and a playful clarinet melody plays. Big Explorers name instruments by ear in music trivia.',
  },
  {
    icon: Footprints,
    title: 'Movement Magic Ladder',
    text: 'An animated friend shows one move at a time, like walk, scoot, squat, or hop, so children get up and move away from the screen.',
  },
  {
    icon: Star,
    title: 'Rewards that last',
    text: 'Stars, explorer badges, room certificates, character accessories, and bonus doors. Progress is saved so children can stop for the day.',
  },
]

const ROOM_STEPS = [
  {
    title: 'Beginning',
    text: 'A friendly welcome explains what to do, out loud and on screen.',
  },
  {
    title: 'Explore',
    text: 'Children touch, listen, and discover at their own pace.',
  },
  {
    title: 'Challenge',
    text: 'A gentle task for toddlers, or a real puzzle for older kids.',
  },
  {
    title: 'Celebrate',
    text: 'Stars, a badge, new rewards, and a choice to keep going or take a break.',
  },
]

const FAQ = [
  {
    q: 'Is the $2.98 demo credited toward the full collection?',
    a: CREDIT_NOTE,
  },
  {
    q: 'How do I unlock what I bought?',
    a: 'Check out at rbvendorsconcierge.com. Once your payment is confirmed, enter the email and order or receipt number from your confirmation on the unlock page. Your doors open right away on that device, and you can unlock other devices the same way.',
  },
  {
    q: 'What devices does it work on?',
    a: 'Any modern browser on a phone, tablet, or computer. There is nothing to download or install. Sound works best with the device volume turned up or headphones on.',
  },
  {
    q: 'Is Little Explorers safe for babies and toddlers?',
    a: 'Little Explorers is designed to be operated by a grown-up sitting with the child. It uses large, calm objects, no flashing effects, no wrong-answer buzzers, and short activities. Grown-ups can lower motion, turn off sounds, and set play-time break reminders.',
  },
  {
    q: 'Do children have to do the movement activities?',
    a: 'No. Movement is optional and meant to be supervised. Grown-ups can switch the Movement Magic Ladder off in settings, and every move suggests a safe, open space.',
  },
  {
    q: 'Will my child lose progress if we stop?',
    a: 'No. Stars, badges, accessories, and completed rooms are saved on the device and to your purchase, so children can pick up where they left off on another day.',
  },
]

function CollectionPage() {
  return (
    <SiteLayout>
      {/* Service overview */}
      <section className="bg-linear-to-b from-secondary/60 to-background">
        <div className="mx-auto max-w-content px-4 py-12 text-center sm:px-6 md:py-16">
          <p className="font-script text-3xl text-rose">our collection</p>
          <h1 className="mt-1 font-display text-4xl font-semibold text-foreground sm:text-5xl">
            The Learning Collection
          </h1>
          <p className="mx-auto mt-4 max-w-reading text-lg text-muted-foreground">
            An interactive learning adventure that plays right in your browser.
            Children step into a magical hallway, open doors into colorful
            rooms, and learn about hair care, laundry, music, movement, colors,
            and shapes through touch, sound, and play. Every room has a
            beginning, a challenge, and a celebration, and every finished
            activity earns rewards they can come back to.
          </p>
          <div className="mx-auto mt-6 flex max-w-reading flex-wrap justify-center gap-2">
            {(Object.keys(MODES) as Mode[]).map((m) => (
              <Badge key={m} variant="secondary" className="px-3 py-1 text-sm">
                {MODES[m].title} · {MODES[m].ages}
              </Badge>
            ))}
          </div>
        </div>
      </section>

      {/* What the service offers */}
      <section
        aria-labelledby="highlights-title"
        className="mx-auto max-w-content px-4 py-12 sm:px-6"
      >
        <h2
          id="highlights-title"
          className="text-center font-display text-3xl font-semibold"
        >
          What your explorer gets to do
        </h2>
        <ul className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {HIGHLIGHTS.map(({ icon: Icon, title, text }) => (
            <li
              key={title}
              className="rounded-xl border border-border bg-card p-6"
            >
              <span className="flex size-11 items-center justify-center rounded-full bg-secondary text-rose">
                <Icon aria-hidden className="size-5" />
              </span>
              <h3 className="mt-4 font-display text-xl font-semibold">
                {title}
              </h3>
              <p className="mt-2 text-sm text-muted-foreground">{text}</p>
            </li>
          ))}
        </ul>
      </section>

      {/* Products */}
      <section aria-labelledby="choose-title" className="bg-linen">
        <div className="mx-auto max-w-content px-4 py-12 sm:px-6">
          <h2
            id="choose-title"
            className="text-center font-display text-3xl font-semibold"
          >
            Choose your adventure
          </h2>
          <p className="mx-auto mt-2 max-w-reading text-center text-muted-foreground">
            Two ways to play. Both are real, hands-on experiences with sounds,
            rewards, and saved progress.
          </p>
          <div className="mt-8 grid gap-6 md:grid-cols-2">
            {(['demo', 'full'] as const).map((key) => {
              const p = PRODUCTS[key]
              const featured = key === 'full'
              return (
                <article
                  key={key}
                  aria-labelledby={`${key}-title`}
                  className={`flex flex-col rounded-2xl border bg-card p-6 sm:p-8 ${
                    featured ? 'border-rose shadow-lg' : 'border-border'
                  }`}
                >
                  <div className="flex items-center justify-between gap-4">
                    <p className="text-xs font-bold tracking-[1.5px] text-rose uppercase">
                      {p.kicker}
                    </p>
                    {featured && <Badge>Best value</Badge>}
                  </div>
                  <h3
                    id={`${key}-title`}
                    className="mt-2 font-display text-2xl font-semibold"
                  >
                    {p.name}
                  </h3>
                  <p className="mt-1 font-display text-4xl font-semibold text-foreground">
                    {p.price}
                  </p>
                  <p className="mt-1 text-sm text-muted-foreground">
                    One-time purchase · {p.bestFor}
                  </p>
                  <div className="mt-4 space-y-3 text-sm leading-relaxed">
                    {p.details.map((d) => (
                      <p key={d}>{d}</p>
                    ))}
                  </div>
                  <h4 className="mt-6 text-sm font-bold">What’s included</h4>
                  <ul className="mt-3 space-y-2 text-sm">
                    {p.includes.map((i) => (
                      <li key={i} className="flex gap-2">
                        <Check
                          aria-hidden
                          className="mt-0.5 size-4 shrink-0 text-rose"
                        />
                        {i}
                      </li>
                    ))}
                  </ul>
                  <div className="mt-auto pt-6">
                    <a
                      href={p.checkoutUrl}
                      target="_blank"
                      rel="noopener"
                      className={`flex items-center justify-center gap-2 rounded-lg px-4 py-3 font-semibold transition-colors focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none motion-reduce:transition-none ${
                        featured
                          ? 'bg-primary text-primary-foreground hover:bg-rose-deep'
                          : 'border border-input bg-background hover:bg-muted'
                      }`}
                    >
                      Get the {p.name}
                      <ExternalLink aria-hidden className="size-4" />
                      <span className="sr-only">
                        (opens rbvendorsconcierge.com in a new tab)
                      </span>
                    </a>
                  </div>
                </article>
              )
            })}
          </div>
          <p className="mx-auto mt-6 flex max-w-reading items-start justify-center gap-2 text-center text-sm text-muted-foreground">
            <Info aria-hidden className="mt-0.5 size-4 shrink-0" />
            {CREDIT_NOTE}
          </p>
        </div>
      </section>

      {/* Room-by-room comparison */}
      <section
        aria-labelledby="rooms-title"
        className="mx-auto max-w-content px-4 py-12 sm:px-6"
      >
        <h2
          id="rooms-title"
          className="text-center font-display text-3xl font-semibold"
        >
          Room by room
        </h2>
        <p className="mx-auto mt-2 max-w-reading text-center text-muted-foreground">
          Each age mode has its own hallway, activities, and difficulty level.
        </p>
        <div className="mt-8 grid gap-8 lg:grid-cols-2">
          {(Object.keys(MODES) as Mode[]).map((m) => (
            <div key={m} className="rounded-xl border border-border bg-card">
              <h3 className="border-b border-border px-4 py-3 font-display text-xl font-semibold">
                {MODES[m].title}{' '}
                <span className="font-sans text-sm font-normal text-muted-foreground">
                  {MODES[m].ages} · {MODES[m].tagline}
                </span>
              </h3>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Room</TableHead>
                    <TableHead className="text-center">Demo</TableHead>
                    <TableHead className="text-center">Full</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {roomsFor(m).map((r) => (
                    <TableRow key={r.id}>
                      <TableCell className="whitespace-normal">
                        <span className="font-semibold">
                          <span aria-hidden>{r.icon} </span>
                          {r.title}
                        </span>
                        <span className="block text-xs text-muted-foreground">
                          {r.tagline}
                          {r.movement && ' · optional, grown-up supervised'}
                        </span>
                      </TableCell>
                      <TableCell className="text-center">
                        <Included
                          yes={r.demo}
                          label={
                            r.movement && r.demo ? 'Starter moves' : undefined
                          }
                        />
                      </TableCell>
                      <TableCell className="text-center">
                        <Included
                          yes
                          label={
                            r.unlockStars
                              ? `Bonus: ${r.unlockStars} stars`
                              : undefined
                          }
                        />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ))}
        </div>
      </section>

      {/* How each room works + every purchase */}
      <section className="bg-linen">
        <div className="mx-auto grid max-w-content gap-10 px-4 py-12 sm:px-6 lg:grid-cols-2">
          <div aria-labelledby="steps-title">
            <h2
              id="steps-title"
              className="font-display text-3xl font-semibold"
            >
              How every room works
            </h2>
            <ol className="mt-6 space-y-4">
              {ROOM_STEPS.map((s, i) => (
                <li key={s.title} className="flex gap-4">
                  <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-primary font-semibold text-primary-foreground">
                    {i + 1}
                  </span>
                  <div>
                    <h3 className="font-semibold">{s.title}</h3>
                    <p className="text-sm text-muted-foreground">{s.text}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
          <div aria-labelledby="every-title">
            <h2
              id="every-title"
              className="font-display text-3xl font-semibold"
            >
              Included with every purchase
            </h2>
            <ul className="mt-6 space-y-3">
              {EVERY_PURCHASE.map((f) => (
                <li key={f} className="flex gap-3 text-sm">
                  <Sparkles
                    aria-hidden
                    className="mt-0.5 size-4 shrink-0 text-gold"
                  />
                  {f}
                </li>
              ))}
            </ul>
            <div className="mt-6 flex gap-3 rounded-xl border border-border bg-card p-4 text-sm">
              <ShieldCheck aria-hidden className="size-5 shrink-0 text-rose" />
              <p>
                <span className="font-semibold">Made for little ones.</span>{' '}
                <span className="text-muted-foreground">
                  Toddler mode is grown-up operated, with no flashing effects
                  and no wrong-answer penalties. Movement is always optional and
                  supervised.
                </span>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section
        aria-labelledby="faq-title"
        className="mx-auto max-w-reading px-4 py-12 sm:px-6"
      >
        <h2
          id="faq-title"
          className="text-center font-display text-3xl font-semibold"
        >
          Good to know
        </h2>
        <Accordion type="single" collapsible className="mt-6">
          {FAQ.map((f) => (
            <AccordionItem key={f.q} value={f.q}>
              <AccordionTrigger className="text-left">{f.q}</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                {f.a}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
        <div className="mt-10 flex flex-col items-center gap-3 text-center">
          <HeartHandshake aria-hidden className="size-8 text-rose" />
          <p className="text-muted-foreground">
            Already purchased, or ready to peek inside?
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <Link
              to="/play"
              className="rounded-lg bg-primary px-5 py-3 font-semibold text-primary-foreground transition-colors hover:bg-rose-deep focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none motion-reduce:transition-none"
            >
              Let’s Start Learning!
            </Link>
            <Link
              to="/unlock"
              className="rounded-lg border border-input px-5 py-3 font-semibold transition-colors hover:bg-muted focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none motion-reduce:transition-none"
            >
              Unlock a purchase
            </Link>
          </div>
        </div>
      </section>
    </SiteLayout>
  )
}

function Included({ yes, label }: { yes: boolean; label?: string }) {
  return yes ? (
    <span className="inline-flex flex-col items-center text-rose">
      <Check aria-hidden className="size-5" />
      <span className="sr-only">Included</span>
      {label && (
        <span className="text-[11px] text-muted-foreground">{label}</span>
      )}
    </span>
  ) : (
    <span className="inline-flex justify-center text-muted-foreground">
      <Minus aria-hidden className="size-5" />
      <span className="sr-only">Not included</span>
    </span>
  )
}
