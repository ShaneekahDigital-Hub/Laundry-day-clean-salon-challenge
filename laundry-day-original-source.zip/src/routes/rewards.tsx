import { Link, createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Award, Lock, Star } from 'lucide-react'
import { SiteLayout } from '@/components/site/SiteLayout'
import { Avatar } from '@/components/game/Avatar'
import { Certificate } from '@/components/game/Certificate'
import { useGame } from '@/components/game/GameProvider'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { ACCESSORIES, ROOMS } from '@/lib/game-data'
import type { Room } from '@/lib/game-data'

export const Route = createFileRoute('/rewards')({
  head: () => ({ meta: [{ title: 'My Rewards | Shaneekah Braids & Locs' }] }),
  component: RewardsPage,
})

function RewardsPage() {
  const { hydrated, progress, stars, toggleAccessory } = useGame()
  const [cert, setCert] = useState<Room | null>(null)
  const done = ROOMS.filter((r) => progress.rooms[r.id])

  return (
    <SiteLayout>
      <div className="mx-auto max-w-content px-4 py-12 sm:px-6">
        <div className="flex flex-col items-center text-center">
          <Avatar size={120} />
          <h1 className="mt-2 font-display text-4xl font-semibold">
            My Rewards
          </h1>
          {hydrated ? (
            <p className="mt-2 flex items-center gap-2 text-lg">
              <Star aria-hidden className="size-5 fill-butter text-gold" />
              <span>
                <strong>{stars}</strong> stars earned
              </span>
            </p>
          ) : (
            <Skeleton className="mt-2 h-7 w-40" />
          )}
        </div>

        <section aria-labelledby="badges-title" className="mt-12">
          <h2 id="badges-title" className="font-display text-2xl font-semibold">
            Explorer badges &amp; certificates
          </h2>
          {!hydrated ? (
            <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {[0, 1, 2].map((i) => (
                <Skeleton key={i} className="h-24 rounded-xl" />
              ))}
            </div>
          ) : done.length === 0 ? (
            <div className="mt-4 rounded-xl border border-dashed border-border p-8 text-center text-muted-foreground">
              No badges yet. Open a door and finish a room to earn your first
              one!
              <div className="mt-4">
                <Link
                  to="/play"
                  className="rounded-lg bg-primary px-5 py-3 font-semibold text-primary-foreground hover:bg-rose-deep"
                >
                  Let’s Start Learning!
                </Link>
              </div>
            </div>
          ) : (
            <ul className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {done.map((r) => (
                <li
                  key={r.id}
                  className="flex items-center gap-4 rounded-xl border border-border bg-card p-4"
                >
                  <span aria-hidden className="text-4xl">
                    {r.icon}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold">{r.badge}</p>
                    <p className="text-xs text-muted-foreground">
                      {r.title} · {'★'.repeat(progress.rooms[r.id].stars)}
                      <span className="sr-only">
                        {progress.rooms[r.id].stars} stars
                      </span>
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setCert(r)}
                    className="rounded-md p-2 text-rose hover:bg-muted focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
                    aria-label={`View ${r.title} certificate`}
                  >
                    <Award aria-hidden className="size-5" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section aria-labelledby="acc-title" className="mt-12">
          <h2 id="acc-title" className="font-display text-2xl font-semibold">
            Kiki’s accessories
          </h2>
          <p className="text-sm text-muted-foreground">
            Earn stars to unlock new things for Kiki to wear.
          </p>
          <ul className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            {ACCESSORIES.map((a) => {
              const open = hydrated && stars >= a.stars
              const worn = progress.equipped.includes(a.id)
              return (
                <li key={a.id}>
                  <button
                    type="button"
                    disabled={!open}
                    aria-pressed={open ? worn : undefined}
                    onClick={() => toggleAccessory(a.id)}
                    className={`flex w-full flex-col items-center gap-1 rounded-xl border p-4 transition-colors focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none motion-reduce:transition-none ${
                      worn
                        ? 'border-rose bg-secondary'
                        : 'border-border bg-card hover:bg-muted'
                    } disabled:opacity-60`}
                  >
                    <span aria-hidden className="text-3xl">
                      {open ? a.emoji : '🎁'}
                    </span>
                    <span className="text-sm font-semibold">{a.name}</span>
                    <span className="flex items-center gap-1 text-xs text-muted-foreground">
                      {open ? (
                        worn ? (
                          'Wearing'
                        ) : (
                          'Tap to wear'
                        )
                      ) : (
                        <>
                          <Lock aria-hidden className="size-3" /> {a.stars}{' '}
                          stars
                        </>
                      )}
                    </span>
                  </button>
                </li>
              )
            })}
          </ul>
        </section>
      </div>

      <Dialog open={cert !== null} onOpenChange={(o) => !o && setCert(null)}>
        <DialogContent className="bg-background">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl">
              Room certificate
            </DialogTitle>
            <DialogDescription>
              Print it and put it on the fridge!
            </DialogDescription>
          </DialogHeader>
          {cert && (
            <>
              <Certificate
                room={cert}
                name={progress.explorerName}
                date={progress.rooms[cert.id]?.completedAt}
              />
              <button
                type="button"
                onClick={() => window.print()}
                className="rounded-lg bg-primary px-4 py-3 font-semibold text-primary-foreground hover:bg-rose-deep"
              >
                Print certificate
              </button>
            </>
          )}
        </DialogContent>
      </Dialog>
    </SiteLayout>
  )
}
