import { Link, createFileRoute } from '@tanstack/react-router'
import { Avatar } from '@/components/game/Avatar'
import { useGame } from '@/components/game/GameProvider'
import { Whirlers } from '@/components/game/Particles'
import { UnlockButton } from '@/components/game/UpgradeInvite'
import { MODES, modeStars, roomsFor } from '@/lib/game-data'
import type { Mode } from '@/lib/game-data'
import { sound } from '@/lib/audio'

export const Route = createFileRoute('/play/')({
  component: ModePicker,
})

const MODE_ART: Record<Mode, { emoji: string; bg: string; points: string[] }> = {
  little: {
    emoji: '🧸',
    bg: 'linear-gradient(150deg, #ff8fc0, #ffd23f)',
    points: ['Colors & shapes', 'Animal sounds', 'Gentle music', 'Grown-up guided'],
  },
  big: {
    emoji: '🧩',
    bg: 'linear-gradient(150deg, #7b3fe4, #3ec5ff)',
    points: ['Puzzles & memory', 'Laundry & salon care', 'Music trivia', 'Movement combos'],
  },
}

function ModePicker() {
  const { access, progress } = useGame()

  return (
    <main className="relative mx-auto max-w-6xl px-4 pt-6 pb-16 sm:px-6">
      <section className="relative flex flex-col items-center text-center">
        <Whirlers count={6} orbit={150} className="top-0 h-56" />
        <Avatar size={140} className="anim-float relative" />
        <h1 className="mt-2 text-4xl font-bold text-white drop-shadow-[0_3px_0_#2b145855] sm:text-5xl">
          Who’s exploring today?
        </h1>
        <p className="mt-2 max-w-xl text-lg text-white/90">
          Pick your adventure world. Each one has its own magical hallway full of doors.
        </p>
      </section>

      {access.status === 'ready' && access.tier === 'none' && (
        <section
          aria-labelledby="locked-title"
          className="game-card mx-auto mt-8 max-w-2xl p-6 text-center"
        >
          <h2 id="locked-title" className="text-2xl font-bold text-g-purple">
            Your doors are waiting to be unlocked ✨
          </h2>
          <p className="mt-2 text-g-ink/80">
            Peek inside the hallways below. A grown-up can unlock the{' '}
            <strong>Demo Adventure ($2.98)</strong> or the <strong>Full Learning Collection ($24.99)</strong>.
          </p>
          <div className="mt-4 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <UnlockButton>See unlock options</UnlockButton>
            <Link to="/unlock" className="font-semibold text-g-purple underline underline-offset-4">
              Already purchased? Unlock here
            </Link>
          </div>
        </section>
      )}
      {access.status === 'ready' && access.tier === 'demo' && (
        <p className="mx-auto mt-6 w-fit rounded-full bg-white/90 px-5 py-2 text-center font-semibold text-g-purple">
          🎟️ Demo Adventure unlocked · Selected doors are open
        </p>
      )}

      <div className="mt-8 grid gap-6 md:grid-cols-2">
        {(Object.keys(MODES) as Mode[]).map((mode) => {
          const info = MODES[mode]
          const art = MODE_ART[mode]
          const total = roomsFor(mode).length * 3
          return (
            <Link
              key={mode}
              to="/play/$mode"
              params={{ mode }}
              onClick={() => sound.pop()}
              className="group relative overflow-hidden rounded-[2rem] p-6 text-white shadow-[0_10px_0_#00000026] transition-transform hover:-translate-y-1 focus-visible:ring-4 focus-visible:ring-white focus-visible:outline-none motion-reduce:transition-none sm:p-8"
              style={{ background: art.bg }}
            >
              <span aria-hidden className="absolute -top-4 -right-2 text-[120px] opacity-30 transition-transform group-hover:rotate-12">
                {art.emoji}
              </span>
              <span className="inline-block rounded-full bg-white/25 px-3 py-1 text-sm font-semibold">{info.ages}</span>
              <h2 className="mt-3 text-4xl font-bold">{info.title}</h2>
              <p className="mt-1 text-lg text-white/90">{info.tagline}</p>
              <ul className="mt-4 grid grid-cols-2 gap-2 text-sm font-semibold">
                {art.points.map((p) => (
                  <li key={p} className="rounded-xl bg-white/20 px-3 py-2">
                    {p}
                  </li>
                ))}
              </ul>
              <div className="mt-5 flex items-center justify-between">
                <span className="text-sm font-semibold">
                  ⭐ {modeStars(progress, mode)} / {total} stars
                </span>
                <span className="chunky-btn bg-white px-5 py-2 text-lg text-g-purple">Enter →</span>
              </div>
            </Link>
          )
        })}
      </div>
    </main>
  )
}
