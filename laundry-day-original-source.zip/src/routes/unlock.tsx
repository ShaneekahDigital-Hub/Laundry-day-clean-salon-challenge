import { Link, createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { CheckCircle2, Loader2 } from 'lucide-react'
import { SiteLayout } from '@/components/site/SiteLayout'
import { useGame } from '@/components/game/GameProvider'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { PRODUCTS } from '@/lib/products'

export const Route = createFileRoute('/unlock')({
  head: () => ({
    meta: [{ title: 'Unlock a purchase | Shaneekah Braids & Locs' }],
  }),
  component: UnlockPage,
})

function UnlockPage() {
  const { access, redeem, signOut } = useGame()
  const [email, setEmail] = useState('')
  const [orderId, setOrderId] = useState('')
  const [pending, setPending] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setPending(true)
    try {
      await redeem(email, orderId)
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Something went wrong. Please try again.',
      )
    } finally {
      setPending(false)
    }
  }

  const unlocked = access.status === 'ready' && access.tier !== 'none'

  return (
    <SiteLayout>
      <div className="mx-auto max-w-lg px-4 py-12 sm:px-6">
        <h1 className="text-center font-display text-4xl font-semibold">
          Unlock your adventure
        </h1>
        <p className="mt-3 text-center text-muted-foreground">
          Enter the email and order or receipt number from your
          rbvendorsconcierge.com confirmation.
        </p>

        {unlocked ? (
          <div className="mt-8 rounded-2xl border border-border bg-card p-6 text-center">
            <CheckCircle2 aria-hidden className="mx-auto size-10 text-rose" />
            <p
              className="mt-3 font-display text-2xl font-semibold"
              role="status"
            >
              {access.tier === 'full' ? PRODUCTS.full.name : PRODUCTS.demo.name}{' '}
              unlocked!
            </p>
            {access.email && (
              <p className="mt-1 text-sm text-muted-foreground">
                {access.email}
              </p>
            )}
            <div className="mt-6 flex flex-col gap-3">
              <Link
                to="/play"
                className="rounded-lg bg-primary px-5 py-3 font-semibold text-primary-foreground hover:bg-rose-deep"
              >
                Let’s Start Learning!
              </Link>
              <button
                type="button"
                onClick={() => void signOut()}
                className="text-sm text-muted-foreground underline"
              >
                Sign out on this device
              </button>
            </div>
          </div>
        ) : (
          <form
            onSubmit={submit}
            className="mt-8 space-y-4 rounded-2xl border border-border bg-card p-6"
            noValidate={false}
          >
            <div className="space-y-2">
              <Label htmlFor="email">Email used at checkout</Label>
              <Input
                id="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="order">Order or receipt number</Label>
              <Input
                id="order"
                required
                value={orderId}
                onChange={(e) => setOrderId(e.target.value)}
              />
            </div>
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            <button
              type="submit"
              disabled={pending || access.status === 'loading'}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-4 py-3 font-semibold text-primary-foreground hover:bg-rose-deep disabled:opacity-60"
            >
              {pending && (
                <Loader2
                  aria-hidden
                  className="size-4 animate-spin motion-reduce:animate-none"
                />
              )}
              Unlock my doors
            </button>
            <p className="text-center text-xs text-muted-foreground">
              Haven’t purchased yet?{' '}
              <Link
                to="/collection"
                className="font-semibold text-rose underline"
              >
                See the collection
              </Link>
            </p>
          </form>
        )}
      </div>
    </SiteLayout>
  )
}
