export type ShapeKind =
  | 'circle'
  | 'square'
  | 'triangle'
  | 'heart'
  | 'star'
  | 'block'
  | 'diamond'

export const SHAPE_NAMES: Record<ShapeKind, string> = {
  circle: 'Circle',
  square: 'Square',
  triangle: 'Triangle',
  heart: 'Heart',
  star: 'Star',
  block: 'Block',
  diamond: 'Diamond',
}

const STAR =
  'M50 6 L62 37 L95 38 L69 58 L78 91 L50 72 L22 91 L31 58 L5 38 L38 37 Z'
const HEART =
  'M50 88 C20 66 6 50 6 32 C6 18 17 8 30 8 C39 8 46 13 50 21 C54 13 61 8 70 8 C83 8 94 18 94 32 C94 50 80 66 50 88 Z'

export function Shape({
  kind,
  color,
  size = 80,
  className,
  title,
}: {
  kind: ShapeKind
  color: string
  size?: number | string
  className?: string
  title?: string
}) {
  const shine = (
    <ellipse cx="34" cy="30" rx="11" ry="7" fill="#fff" opacity="0.45" transform="rotate(-25 34 30)" />
  )
  return (
    <svg
      viewBox="0 0 100 100"
      width={size}
      height={size}
      className={className}
      role={title ? 'img' : undefined}
      aria-label={title}
      aria-hidden={title ? undefined : true}
    >
      <g stroke="#00000022" strokeWidth="3" strokeLinejoin="round">
        {kind === 'circle' && <circle cx="50" cy="50" r="42" fill={color} />}
        {kind === 'square' && <rect x="10" y="10" width="80" height="80" rx="12" fill={color} />}
        {kind === 'triangle' && <path d="M50 8 L94 88 L6 88 Z" fill={color} />}
        {kind === 'heart' && <path d={HEART} fill={color} />}
        {kind === 'star' && <path d={STAR} fill={color} />}
        {kind === 'diamond' && <path d="M50 4 L92 50 L50 96 L8 50 Z" fill={color} />}
        {kind === 'block' && (
          <>
            <path d="M14 30 L50 14 L86 30 L50 46 Z" fill={color} style={{ filter: 'brightness(1.25)' }} />
            <path d="M14 30 L50 46 L50 90 L14 74 Z" fill={color} />
            <path d="M86 30 L50 46 L50 90 L86 74 Z" fill={color} style={{ filter: 'brightness(0.8)' }} />
          </>
        )}
      </g>
      {kind !== 'block' && shine}
    </svg>
  )
}
