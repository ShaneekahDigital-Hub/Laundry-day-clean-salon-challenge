import { Crown } from 'lucide-react'
import type { Room } from '@/lib/game-data'

/** Printable room-completion certificate in the boutique brand style. */
export function Certificate({ room, name, date }: { room: Room; name: string; date?: string }) {
  const when = date ? new Date(date) : new Date()
  return (
    <div className="certificate relative overflow-hidden rounded-xl border-[10px] border-double border-gold bg-[#fffaf1] p-6 text-center text-foreground sm:p-8">
      <Crown aria-hidden className="mx-auto size-8 text-gold" />
      <p className="mt-1 text-[10px] font-bold tracking-[3px] text-muted-foreground uppercase">
        Shaneekah Braids &amp; Locs · The Learning Collection
      </p>
      <p className="mt-4 font-script text-4xl text-rose">Certificate of Sparkle</p>
      <p className="mt-3 text-sm text-muted-foreground">This certifies that</p>
      <p className="mt-1 font-display text-3xl font-semibold">{name || 'Our Little Explorer'}</p>
      <p className="mt-3 text-sm text-muted-foreground">completed</p>
      <p className="mt-1 font-display text-xl font-semibold">
        {room.icon} {room.title}
      </p>
      <p className="mt-2 text-sm">
        and earned the <strong className="text-rose">{room.badge}</strong> badge
      </p>
      <p className="mt-5 text-xs text-muted-foreground">
        {when.toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })}
      </p>
      <p className="mt-2 font-script text-xl text-rose">Little lessons. Big confidence.</p>
    </div>
  )
}
