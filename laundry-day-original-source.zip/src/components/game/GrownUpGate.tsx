import { useEffect, useState } from 'react'
import { Lock } from 'lucide-react'

/** A quick "grown-ups only" check before settings, purchases, or more play time. */
export function GrownUpGate({
  onPass,
  reason = 'This part is for grown-ups.',
}: {
  onPass: () => void
  reason?: string
}) {
  const [q, setQ] = useState<{ a: number; b: number; options: number[] } | null>(null)
  const [wrong, setWrong] = useState(false)

  const fresh = () => {
    const a = 6 + Math.floor(Math.random() * 4)
    const b = 5 + Math.floor(Math.random() * 4)
    const answer = a * b
    const options = [answer, answer + a, answer - b].sort(() => Math.random() - 0.5)
    setQ({ a, b, options })
  }
  useEffect(fresh, [])

  if (!q) return null
  return (
    <div className="space-y-4 text-center">
      <div className="mx-auto flex size-12 items-center justify-center rounded-full bg-secondary text-rose">
        <Lock aria-hidden className="size-5" />
      </div>
      <p className="text-sm text-muted-foreground">{reason}</p>
      <p className="font-display text-xl font-semibold" id="gate-q">
        What is {q.a} × {q.b}?
      </p>
      <div role="group" aria-labelledby="gate-q" className="flex justify-center gap-3">
        {q.options.map((n) => (
          <button
            key={n}
            type="button"
            onClick={() => {
              if (n === q.a * q.b) onPass()
              else {
                setWrong(true)
                fresh()
              }
            }}
            className="min-w-16 rounded-xl border border-input bg-card px-4 py-3 text-lg font-semibold hover:bg-muted focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
          >
            {n}
          </button>
        ))}
      </div>
      {wrong && (
        <p role="status" className="text-sm text-muted-foreground">
          Not quite — here’s a new one.
        </p>
      )}
    </div>
  )
}
