import { useGame } from './GameProvider'

/**
 * Kiki, the explorer guide: a friendly girl with locs. Earned accessories
 * appear on her, and the `move` prop makes her demonstrate ladder moves.
 */
export function Avatar({
  size = 160,
  accessories,
  move,
  className = '',
  label = 'Kiki the explorer',
}: {
  size?: number
  accessories?: string[]
  move?: string
  className?: string
  label?: string
}) {
  const { progress } = useGame()
  const worn = new Set(accessories ?? progress.equipped)
  const body = MOVE_STYLE[move ?? ''] ?? {}
  const armAnim = move === 'arms' ? 'kiki-arms 1.4s linear infinite' : undefined

  return (
    <svg
      viewBox="0 0 200 240"
      width={size}
      height={(size * 240) / 200}
      role="img"
      aria-label={label}
      className={className}
    >
      <style>{`
        @keyframes kiki-arms { from { transform: rotate(0deg) } to { transform: rotate(360deg) } }
        @keyframes kiki-blink { 0%, 92%, 100% { transform: scaleY(1) } 95% { transform: scaleY(0.1) } }
        @keyframes kiki-walk { 0%,100% { transform: rotate(-8deg) } 50% { transform: rotate(8deg) } }
        @media (prefers-reduced-motion: reduce) { .kiki-anim { animation: none !important } }
      `}</style>
      <g className="kiki-anim" style={{ transformOrigin: '100px 200px', transformBox: 'view-box', ...body }}>
        {worn.has('cape') && (
          <path d="M62 128 Q100 116 138 128 L156 222 Q100 236 44 222 Z" fill="#7b3fe4" stroke="#5a2bb0" strokeWidth="3" />
        )}
        {/* legs */}
        <g
          className="kiki-anim"
          style={{
            transformOrigin: '100px 190px',
            transformBox: 'view-box',
            animation: move === 'walk' || move === 'run' ? `kiki-walk ${move === 'run' ? 0.4 : 0.8}s ease-in-out infinite` : undefined,
          }}
        >
          <rect x="80" y="186" width="14" height="36" rx="7" fill="#7a4a32" />
          <rect x="106" y="186" width="14" height="36" rx="7" fill="#7a4a32" />
          <ellipse cx="86" cy="224" rx="13" ry="7" fill="#ff5fa2" />
          <ellipse cx="114" cy="224" rx="13" ry="7" fill="#ff5fa2" />
        </g>
        {/* arms */}
        <g className="kiki-anim" style={{ transformOrigin: '66px 140px', transformBox: 'view-box', animation: armAnim }}>
          <rect x="44" y="134" width="30" height="13" rx="6.5" fill="#7a4a32" transform="rotate(35 66 140)" />
        </g>
        <g className="kiki-anim" style={{ transformOrigin: '134px 140px', transformBox: 'view-box', animation: armAnim }}>
          <rect x="126" y="134" width="30" height="13" rx="6.5" fill="#7a4a32" transform="rotate(-35 134 140)" />
          {worn.has('wand') && (
            <g transform="translate(150 118) rotate(-25)">
              <rect x="-2" y="0" width="4" height="34" rx="2" fill="#ffd23f" />
              <path d="M0 -14 L4 -4 L14 -4 L6 2 L9 12 L0 6 L-9 12 L-6 2 L-14 -4 L-4 -4 Z" fill="#ffd23f" stroke="#e0a800" strokeWidth="1.5" />
            </g>
          )}
        </g>
        {/* dress */}
        <path d="M72 124 Q100 112 128 124 L146 192 Q100 204 54 192 Z" fill="#ff5fa2" />
        <path d="M60 178 Q100 190 140 178" stroke="#ffd23f" strokeWidth="6" fill="none" strokeLinecap="round" />
        <circle cx="100" cy="148" r="6" fill="#ffd23f" />
        {/* locs (back) */}
        <g fill="#3a2318">
          {[-52, -40, -28, 28, 40, 52].map((dx, i) => (
            <rect key={i} x={100 + dx - 7} y="54" width="14" height={i === 0 || i === 5 ? 78 : 88} rx="7" />
          ))}
        </g>
        {/* head */}
        <circle cx="100" cy="76" r="44" fill="#8b5a3c" />
        {/* hair top */}
        <path d="M56 70 Q60 30 100 28 Q140 30 144 70 Q130 50 100 50 Q70 50 56 70 Z" fill="#3a2318" />
        {[70, 85, 100, 115, 130].map((x) => (
          <circle key={x} cx={x} cy="40" r="9" fill="#3a2318" />
        ))}
        {/* face */}
        <g style={{ transformOrigin: '100px 78px', transformBox: 'view-box', animation: 'kiki-blink 5s infinite' }} className="kiki-anim">
          <ellipse cx="84" cy="78" rx="5" ry="6.5" fill="#2b1458" />
          <ellipse cx="116" cy="78" rx="5" ry="6.5" fill="#2b1458" />
          <circle cx="86" cy="76" r="1.8" fill="#fff" />
          <circle cx="118" cy="76" r="1.8" fill="#fff" />
        </g>
        <circle cx="74" cy="92" r="7" fill="#ff8fb8" opacity="0.6" />
        <circle cx="126" cy="92" r="7" fill="#ff8fb8" opacity="0.6" />
        <path d="M88 96 Q100 108 112 96" stroke="#2b1458" strokeWidth="4" fill="none" strokeLinecap="round" />
        {/* accessories */}
        {worn.has('sunglasses') && (
          <g>
            <rect x="70" y="69" width="26" height="18" rx="8" fill="#2b1458" stroke="#ff5fa2" strokeWidth="3" />
            <rect x="104" y="69" width="26" height="18" rx="8" fill="#2b1458" stroke="#ff5fa2" strokeWidth="3" />
            <rect x="94" y="75" width="12" height="4" fill="#ff5fa2" />
            <rect x="75" y="72" width="7" height="4" rx="2" fill="#fff" opacity="0.6" />
          </g>
        )}
        {worn.has('headphones') && (
          <g>
            <path d="M54 76 Q54 26 100 26 Q146 26 146 76" stroke="#3ec5ff" strokeWidth="8" fill="none" />
            <rect x="44" y="66" width="20" height="30" rx="9" fill="#3ec5ff" stroke="#1a8fc2" strokeWidth="2" />
            <rect x="136" y="66" width="20" height="30" rx="9" fill="#3ec5ff" stroke="#1a8fc2" strokeWidth="2" />
          </g>
        )}
        {worn.has('crown') && (
          <g transform="translate(100 24)">
            <path d="M-26 6 L-26 -14 L-13 -2 L0 -20 L13 -2 L26 -14 L26 6 Z" fill="#ffd23f" stroke="#e0a800" strokeWidth="2.5" strokeLinejoin="round" />
            <circle cx="0" cy="-2" r="4" fill="#ff5fa2" />
            <circle cx="-16" cy="2" r="3" fill="#2ed47a" />
            <circle cx="16" cy="2" r="3" fill="#3ec5ff" />
          </g>
        )}
        {worn.has('bow') && (
          <g transform="translate(140 42) rotate(20)">
            <path d="M0 0 L-20 -12 L-20 12 Z" fill="#ff5fa2" stroke="#d6337a" strokeWidth="2" strokeLinejoin="round" />
            <path d="M0 0 L20 -12 L20 12 Z" fill="#ff5fa2" stroke="#d6337a" strokeWidth="2" strokeLinejoin="round" />
            <circle r="6" fill="#ff8fc0" stroke="#d6337a" strokeWidth="2" />
          </g>
        )}
      </g>
    </svg>
  )
}

/** Whole-body demonstration animations for the Movement Magic Ladder. */
const MOVE_STYLE: Record<string, React.CSSProperties> = {
  squat: { ['--my' as string]: '24px', ['--ms' as string]: '0.82', animation: 'demo-move 1.6s ease-in-out infinite' },
  crouch: { ['--my' as string]: '34px', ['--ms' as string]: '0.72', animation: 'demo-move 1.8s ease-in-out infinite' },
  kneel: { ['--my' as string]: '30px', ['--ms' as string]: '0.78', animation: 'demo-move 2s ease-in-out infinite' },
  bend: { ['--mr' as string]: '28deg', ['--my' as string]: '8px', animation: 'demo-move 2s ease-in-out infinite' },
  jump: { ['--my' as string]: '-36px', animation: 'demo-move 0.8s ease-in-out infinite' },
  hop: { ['--my' as string]: '-22px', ['--mr' as string]: '-6deg', animation: 'demo-move 0.6s ease-in-out infinite' },
  walk: { animation: 'climb 0.8s ease-in-out infinite' },
  run: { animation: 'climb 0.4s ease-in-out infinite' },
  roll: { animation: 'kiki-roll 2.4s ease-in-out infinite' },
  lie: { transform: 'rotate(-90deg) translateX(-30px)', transition: 'transform 0.8s ease' },
  scoot: { ['--my' as string]: '30px', ['--ms' as string]: '0.75', animation: 'kiki-scoot 2s ease-in-out infinite' },
  arms: {},
}
