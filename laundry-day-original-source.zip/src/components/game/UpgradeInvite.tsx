import { useState } from 'react'
import { ExternalLink, Sparkles } from 'lucide-react'
import { GrownUpGate } from './GrownUpGate'
import { CREDIT_NOTE, PRODUCTS } from '@/lib/products'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Link } from '@tanstack/react-router'

/** "Unlock My Full Adventure": always behind a grown-up check before leaving the game. */
export function UnlockButton({ className = '', children }: { className?: string; children?: React.ReactNode }) {
  const [open, setOpen] = useState(false)
  const [passed, setPassed] = useState(false)
  return (
    <>
      <button
        type="button"
        onClick={() => {
          setPassed(false)
          setOpen(true)
        }}
        className={`chunky-btn inline-flex items-center justify-center gap-2 bg-g-yellow px-6 py-3 text-lg text-g-ink focus-visible:ring-4 focus-visible:ring-white focus-visible:outline-none ${className}`}
      >
        <Sparkles aria-hidden className="size-5" />
        {children ?? 'Unlock My Full Adventure'}
      </button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-background">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl">{PRODUCTS.full.name} · {PRODUCTS.full.price}</DialogTitle>
            <DialogDescription>Checkout happens securely at rbvendorsconcierge.com.</DialogDescription>
          </DialogHeader>
          {passed ? (
            <div className="space-y-4 text-sm">
              <ul className="list-disc space-y-1 pl-5 text-muted-foreground">
                {PRODUCTS.full.includes.map((i) => (
                  <li key={i}>{i}</li>
                ))}
              </ul>
              <p className="rounded-lg bg-muted p-3 text-xs text-muted-foreground">{CREDIT_NOTE}</p>
              <a
                href={PRODUCTS.full.checkoutUrl}
                target="_blank"
                rel="noopener"
                className="flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-4 py-3 font-semibold text-primary-foreground hover:bg-rose-deep"
              >
                Continue to checkout <ExternalLink aria-hidden className="size-4" />
              </a>
              <p className="text-center text-xs text-muted-foreground">
                After paying, use the email and receipt number from your confirmation on the{' '}
                <Link to="/unlock" className="font-semibold text-rose underline">
                  unlock page
                </Link>
                .
              </p>
            </div>
          ) : (
            <GrownUpGate onPass={() => setPassed(true)} reason="Grown-ups: answer to see purchase options." />
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}

export function UpgradeInvite() {
  return (
    <section
      aria-labelledby="upgrade-title"
      className="anim-pop-in relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-g-purple via-[#a43fd6] to-g-pink p-6 text-center text-white shadow-xl sm:p-8"
    >
      <p className="text-4xl" aria-hidden>🚪✨🚪</p>
      <h2 id="upgrade-title" className="mt-2 text-3xl font-bold">
        Ready for the whole adventure?
      </h2>
      <p className="mx-auto mt-2 max-w-md text-lg text-white/90">
        You’ve discovered the magic. Now unlock the entire Learning Collection for $24.99!
      </p>
      <UnlockButton className="mt-5" />
      <p className="mx-auto mt-4 max-w-md text-xs text-white/75">{CREDIT_NOTE}</p>
    </section>
  )
}
