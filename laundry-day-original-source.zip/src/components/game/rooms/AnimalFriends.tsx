import { useMemo, useState } from 'react'
import { Volume2 } from 'lucide-react'
import { Shape } from '../Shape'
import { Prompt, StepPills } from './StepPills'
import type { RoomProps } from './types'
import { centerOf } from './types'
import { sound } from '@/lib/audio'

const ANIMALS = [
  { id: 'cat', name: 'Cat', emoji: '🐱', says: 'Meow', bg: '#ffe0ef', play: () => sound.meow() },
  { id: 'dog', name: 'Dog', emoji: '🐶', says: 'Woof woof', bg: '#fff1c7', play: () => sound.bark() },
  { id: 'duck', name: 'Duck', emoji: '🦆', says: 'Quack quack', bg: '#dff7ff', play: () => sound.quack() },
  { id: 'cow', name: 'Cow', emoji: '🐮', says: 'Moo', bg: '#e6ffe9', play: () => sound.moo() },
  { id: 'bird', name: 'Bird', emoji: '🐤', says: 'Tweet tweet', bg: '#efe6ff', play: () => sound.tweet() },
]

export function AnimalFriends({ burst, onComplete }: RoomProps) {
  const [met, setMet] = useState<Set<string>>(new Set())
  const [active, setActive] = useState<string | null>(null)
  const [stage, setStage] = useState<'explore' | 'challenge'>('explore')
  const [round, setRound] = useState(0)
  const [starred, setStarred] = useState<string | null>(null)
  // Cats and dogs always appear, plus one surprise friend.
  const quiz = useMemo(() => {
    const extra = ANIMALS.slice(2)[Math.floor(Math.random() * 3)]
    return [ANIMALS[0], ANIMALS[1], extra]
  }, [])
  const target = quiz[round]

  const ask = (i: number) => {
    sound.say(`Who says ${quiz[i].says}?`)
    window.setTimeout(() => quiz[i].play(), 1500)
  }

  const tap = (a: (typeof ANIMALS)[number], el: HTMLElement) => {
    setActive(a.id)
    window.setTimeout(() => setActive(null), 700)
    const [x, y] = centerOf(el)
    if (stage === 'explore') {
      a.play()
      window.setTimeout(() => sound.say(`${a.name}! ${a.says}!`), 700)
      burst(x, y, 6)
      const next = new Set(met).add(a.id)
      setMet(next)
      if (next.size === ANIMALS.length)
        window.setTimeout(() => {
          setStage('challenge')
          ask(0)
        }, 2200)
      return
    }
    if (a.id === target.id) {
      a.play()
      sound.success()
      burst(x, y, 14)
      setStarred(a.id)
      window.setTimeout(() => setStarred(null), 1400)
      if (round + 1 >= quiz.length) window.setTimeout(() => onComplete(3), 1600)
      else
        window.setTimeout(() => {
          setRound(round + 1)
          ask(round + 1)
        }, 1700)
    } else {
      a.play()
      window.setTimeout(() => sound.say(`That's the ${a.name}! Listen again.`), 600)
      window.setTimeout(() => target.play(), 2600)
    }
  }

  return (
    <div className="space-y-5">
      <StepPills current={stage === 'explore' ? 'Explore' : 'Challenge'} />
      <Prompt>
        {stage === 'explore' ? (
          <>Say hello to every friend! ({met.size}/{ANIMALS.length})</>
        ) : (
          <span className="inline-flex items-center gap-3">
            Who says “{target.says}”?
            <button
              type="button"
              onClick={() => target.play()}
              className="chunky-btn flex size-12 items-center justify-center bg-g-purple text-white"
              aria-label="Hear the sound again"
            >
              <Volume2 aria-hidden className="size-6" />
            </button>
          </span>
        )}
      </Prompt>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {ANIMALS.map((a, i) => (
          <button
            key={a.id}
            type="button"
            onClick={(e) => tap(a, e.currentTarget)}
            aria-label={a.name}
            className="relative flex aspect-square flex-col items-center justify-center rounded-[2rem] border-4 border-white shadow-[0_8px_0_#0001] focus-visible:ring-4 focus-visible:ring-g-purple focus-visible:outline-none"
            style={{ background: a.bg }}
          >
            {starred === a.id ? (
              <Shape kind="star" color="#ffd23f" size={110} className="anim-twirl-in" />
            ) : (
              <span
                aria-hidden
                className={`anim-float text-[72px] leading-none sm:text-[84px] ${active === a.id ? 'anim-boing' : ''}`}
                style={{ animationDelay: `${i * -0.9}s` }}
              >
                {a.emoji}
              </span>
            )}
            <span className="mt-2 text-xl font-bold">{a.name}</span>
            {active === a.id && stage === 'explore' && (
              <span className="anim-pop-in absolute -top-3 rounded-full bg-white px-3 py-1 text-base font-bold shadow">
                {a.says}!
              </span>
            )}
          </button>
        ))}
      </div>
    </div>
  )
}
