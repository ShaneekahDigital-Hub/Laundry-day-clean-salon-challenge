import { useMemo, useState } from 'react'
import { Shape, SHAPE_NAMES } from '../Shape'
import type { ShapeKind } from '../Shape'
import { Prompt, StepPills } from './StepPills'
import type { RoomProps } from './types'
import { centerOf } from './types'
import { sound } from '@/lib/audio'

// Everyday objects that transform into the shape they look like.
const OBJECTS: { id: string; object: string; emoji: string; shape: ShapeKind; color: string }[] = [
  { id: 'donut', object: 'Donut', emoji: '🍩', shape: 'circle', color: '#ff5fa2' },
  { id: 'gift', object: 'Present', emoji: '🎁', shape: 'square', color: '#3e8bff' },
  { id: 'pizza', object: 'Pizza', emoji: '🍕', shape: 'triangle', color: '#ff8a3d' },
  { id: 'letter', object: 'Love note', emoji: '💌', shape: 'heart', color: '#ff4b5c' },
  { id: 'wand', object: 'Magic wand', emoji: '🪄', shape: 'star', color: '#ffd23f' },
  { id: 'toy', object: 'Toy box', emoji: '🧸', shape: 'block', color: '#2ed47a' },
]

export function ShapeParade({ burst, onComplete }: RoomProps) {
  const [transformed, setTransformed] = useState<Set<string>>(new Set())
  const [stage, setStage] = useState<'explore' | 'challenge'>('explore')
  const [round, setRound] = useState(0)
  const [spin, setSpin] = useState<string | null>(null)
  const quiz = useMemo<ShapeKind[]>(() => {
    const kinds: ShapeKind[] = ['circle', 'square', 'triangle', 'heart', 'star']
    return kinds.sort(() => Math.random() - 0.5).slice(0, 3)
  }, [])
  const target = quiz[round]

  const tap = (o: (typeof OBJECTS)[number], el: HTMLElement, i: number) => {
    const [x, y] = centerOf(el)
    setSpin(o.id)
    window.setTimeout(() => setSpin(null), 700)
    if (stage === 'explore') {
      const isShape = transformed.has(o.id)
      const next = new Set(transformed)
      if (isShape) next.delete(o.id)
      else next.add(o.id)
      setTransformed(next)
      sound.sparkle()
      sound.note(i)
      sound.say(isShape ? o.object : `${o.object} turns into a ${SHAPE_NAMES[o.shape]}!`)
      burst(x, y, 8)
      if (!isShape && next.size === OBJECTS.length)
        window.setTimeout(() => {
          setStage('challenge')
          sound.say(`Can you find the ${SHAPE_NAMES[quiz[0]]}?`)
        }, 2200)
      return
    }
    if (o.shape === target) {
      sound.success()
      burst(x, y, 14)
      sound.say(`Yes! ${SHAPE_NAMES[o.shape]}!`)
      if (round + 1 >= quiz.length) window.setTimeout(() => onComplete(3), 1500)
      else
        window.setTimeout(() => {
          setRound(round + 1)
          sound.say(`Can you find the ${SHAPE_NAMES[quiz[round + 1]]}?`)
        }, 1500)
    } else {
      sound.pop()
      sound.say(`That's a ${SHAPE_NAMES[o.shape]}. Let's find the ${SHAPE_NAMES[target]}.`)
    }
  }

  return (
    <div className="space-y-5">
      <StepPills current={stage === 'explore' ? 'Explore' : 'Challenge'} />
      <Prompt>
        {stage === 'explore' ? (
          <>Tap each thing to make it a shape! ({transformed.size}/{OBJECTS.length})</>
        ) : (
          <>Find the {SHAPE_NAMES[target]}! 👀</>
        )}
      </Prompt>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 sm:gap-6">
        {OBJECTS.map((o, i) => {
          const asShape = stage === 'challenge' || transformed.has(o.id)
          return (
            <button
              key={o.id}
              type="button"
              onClick={(e) => tap(o, e.currentTarget, i)}
              aria-label={asShape ? SHAPE_NAMES[o.shape] : o.object}
              className="flex aspect-square flex-col items-center justify-center rounded-[2rem] bg-white/70 shadow-[0_8px_0_#0001] focus-visible:ring-4 focus-visible:ring-g-purple focus-visible:outline-none"
            >
              <span
                className={`anim-float ${spin === o.id ? 'anim-boing' : ''}`}
                style={{ animationDelay: `${i * -0.8}s` }}
              >
                {asShape ? (
                  <Shape key="shape" kind={o.shape} color={o.color} size={110} className="anim-twirl-in" />
                ) : (
                  <span key="obj" aria-hidden className="anim-pop-in block text-[84px] leading-none">
                    {o.emoji}
                  </span>
                )}
              </span>
              <span className="mt-2 text-xl font-bold" style={{ color: asShape ? o.color : undefined }}>
                {asShape ? SHAPE_NAMES[o.shape] : o.object}
              </span>
            </button>
          )
        })}
      </div>
    </div>
  )
}
