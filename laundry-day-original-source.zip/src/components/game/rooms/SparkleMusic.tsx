import { useState } from 'react'
import { InstrumentArt } from './Instruments'
import { Prompt, StepPills } from './StepPills'
import type { RoomProps } from './types'
import { centerOf } from './types'
import { useGame } from '../GameProvider'
import { sound } from '@/lib/audio'

const NOTE_COLORS = ['#ff4b5c', '#ff8a3d', '#ffd23f', '#2ed47a', '#3e8bff', '#8a4fff']
const ROUNDS = 4

export function SparkleMusic({ burst, onComplete }: RoomProps) {
  const { settings } = useGame()
  const [stage, setStage] = useState<'explore' | 'challenge'>('explore')
  const [songPlays, setSongPlays] = useState(0)
  const [playingNote, setPlayingNote] = useState<number | null>(null)
  const [floaters, setFloaters] = useState<{ id: number; color: string; left: number }[]>([])
  const [glow, setGlow] = useState<number | null>(null)
  const [round, setRound] = useState(0)
  const [lit, setLit] = useState<number | null>(null)

  const floatNote = (color: string) => {
    const id = Date.now() + Math.random()
    setFloaters((f) => [...f.slice(-8), { id, color, left: 20 + Math.random() * 60 }])
    window.setTimeout(() => setFloaters((f) => f.filter((n) => n.id !== id)), 1600)
  }

  const playSong = () => {
    const ms = sound.playClarinetSong((i) => {
      setPlayingNote(i)
      floatNote(NOTE_COLORS[i % NOTE_COLORS.length])
    })
    window.setTimeout(() => setPlayingNote(null), ms || 300)
    if (!ms) sound.say('Turn on music in grown-up settings to hear Clara play.')
    const plays = songPlays + 1
    setSongPlays(plays)
    if (stage === 'explore' && plays >= 1)
      window.setTimeout(() => {
        setStage('challenge')
        const first = Math.floor(Math.random() * 6)
        setGlow(first)
        sound.say('Now tap the glowing star!')
      }, (ms || 300) + 600)
  }

  const tapStar = (i: number, el: HTMLElement) => {
    sound.note(i)
    floatNote(NOTE_COLORS[i])
    setLit(i)
    window.setTimeout(() => setLit(null), 400)
    const [x, y] = centerOf(el)
    if (stage === 'challenge' && i === glow) {
      burst(x, y, 10)
      sound.sparkle()
      if (round + 1 >= ROUNDS) {
        setGlow(null)
        window.setTimeout(() => onComplete(3), 1100)
      } else {
        setRound(round + 1)
        let nextGlow = Math.floor(Math.random() * 6)
        if (nextGlow === i) nextGlow = (nextGlow + 2) % 6
        setGlow(null)
        window.setTimeout(() => setGlow(nextGlow), 700)
      }
    }
  }

  return (
    <div className="space-y-5">
      <StepPills current={stage === 'explore' ? 'Explore' : 'Challenge'} />
      <Prompt>
        {stage === 'explore' ? 'Tap Clara the clarinet to hear her song! 🎶' : `Tap the glowing star! (${round}/${ROUNDS})`}
      </Prompt>
      <div className="relative flex flex-col items-center gap-6 rounded-[2rem] bg-gradient-to-b from-[#efe3ff] to-[#ffe3f3] p-6 shadow-inner">
        <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden rounded-[2rem]">
          {floaters.map((f) => (
            <span
              key={f.id}
              className="particle text-4xl"
              style={
                {
                  left: `${f.left}%`,
                  top: '45%',
                  color: f.color,
                  '--dx': '0px',
                  '--dy': '-160px',
                  '--rot': '20deg',
                  '--dur': '1500ms',
                } as React.CSSProperties
              }
            >
              ♪
            </span>
          ))}
        </div>
        <button
          type="button"
          onClick={playSong}
          aria-label="Clara the clarinet. Tap to play her song."
          className={`relative flex flex-col items-center rounded-[2rem] bg-white px-8 py-4 shadow-[0_8px_0_#0001] focus-visible:ring-4 focus-visible:ring-g-purple focus-visible:outline-none ${playingNote !== null ? 'anim-boing' : 'anim-float'}`}
          key={playingNote ?? 'idle'}
        >
          <InstrumentArt id="clarinet" size={140} />
          <span className="text-2xl font-bold text-g-purple">Clara the Clarinet</span>
          <span className="text-sm text-g-ink/70">{settings.music ? 'Tap to play' : 'Music is off'}</span>
        </button>
        <div className="grid grid-cols-3 gap-4 sm:grid-cols-6">
          {NOTE_COLORS.map((c, i) => (
            <button
              key={c}
              type="button"
              onClick={(e) => tapStar(i, e.currentTarget)}
              aria-label={`Music star ${i + 1}${glow === i ? ', glowing' : ''}`}
              className={`flex size-20 items-center justify-center rounded-full bg-white/80 text-5xl transition-transform focus-visible:ring-4 focus-visible:ring-g-purple focus-visible:outline-none sm:size-24 motion-reduce:transition-none ${lit === i ? 'scale-110' : ''}`}
              style={{
                color: c,
                boxShadow: glow === i ? `0 0 0 6px ${c}66, 0 0 24px 8px ${c}88` : '0 6px 0 #0001',
              }}
            >
              <span aria-hidden className={glow === i ? 'anim-twinkle' : ''}>★</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
