const STEPS = ['Begin', 'Explore', 'Challenge', 'Finish'] as const
export type Step = (typeof STEPS)[number]

/** Shows where the child is in the room: beginning, activity, challenge, completion. */
export function StepPills({ current }: { current: Step }) {
  const idx = STEPS.indexOf(current)
  return (
    <ol aria-label="Room progress" className="flex flex-wrap justify-center gap-1.5 sm:gap-2">
      {STEPS.map((s, i) => (
        <li
          key={s}
          aria-current={i === idx ? 'step' : undefined}
          className={`rounded-full px-3 py-1 text-xs font-bold sm:text-sm ${
            i < idx ? 'bg-g-green text-white' : i === idx ? 'bg-g-yellow text-g-ink' : 'bg-white/50 text-g-ink/60'
          }`}
        >
          {i < idx ? '✓ ' : ''}
          {s}
        </li>
      ))}
    </ol>
  )
}

export function Prompt({ children }: { children: React.ReactNode }) {
  return (
    <p role="status" aria-live="polite" className="game-card mx-auto w-fit max-w-full px-5 py-3 text-center text-xl font-bold sm:text-2xl">
      {children}
    </p>
  )
}
