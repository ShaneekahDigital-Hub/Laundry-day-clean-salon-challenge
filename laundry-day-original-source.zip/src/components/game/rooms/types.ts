export interface RoomProps {
  /** Running on the $2.98 Demo Adventure (shorter versions of some activities). */
  demo: boolean
  /** Toddler mode: gentler effects, no wrong answers. */
  gentle: boolean
  burst: (clientX?: number, clientY?: number, amount?: number) => void
  onComplete: (stars: number) => void
}

/** Center of an element, for anchoring sparkle bursts on keyboard presses too. */
export function centerOf(el: Element) {
  const r = el.getBoundingClientRect()
  return [r.left + r.width / 2, r.top + r.height / 2] as const
}
