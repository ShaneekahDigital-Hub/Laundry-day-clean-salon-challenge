import type { ComponentType } from 'react'
import { AnimalFriends } from './AnimalFriends'
import { ColorGarden } from './ColorGarden'
import { ShapeParade } from './ShapeParade'
import { SparkleMusic } from './SparkleMusic'
import type { RoomProps } from './types'
import type { RoomId } from '@/lib/game-data'

function ComingSoon({ onComplete }: RoomProps) {
  return (
    <div className="game-card mx-auto max-w-md p-6 text-center">
      <p className="text-5xl" aria-hidden>🚧✨</p>
      <p className="mt-2 text-2xl font-bold text-g-purple">This room is still being decorated!</p>
      <button type="button" onClick={() => onComplete(1)} className="chunky-btn mt-4 bg-g-pink px-6 py-3 text-white">
        Collect a star
      </button>
    </div>
  )
}

export const ROOM_COMPONENTS: Record<RoomId, ComponentType<RoomProps>> = {
  'color-garden': ColorGarden,
  'animal-friends': AnimalFriends,
  'shape-parade': ShapeParade,
  'sparkle-music': SparkleMusic,
  'little-movement': ComingSoon,
  'laundry-day': ComingSoon,
  'clean-salon': ComingSoon,
  'memory-match': ComingSoon,
  'music-trivia': ComingSoon,
  'big-movement': ComingSoon,
  'pattern-castle': ComingSoon,
}
