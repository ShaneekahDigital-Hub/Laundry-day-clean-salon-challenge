import type { Instrument } from '@/lib/audio'

export const INSTRUMENTS: { id: Instrument; name: string; emoji?: string; fact: string }[] = [
  { id: 'clarinet', name: 'Clarinet', fact: 'A clarinet is a woodwind. You blow across a thin reed to make it sing!' },
  { id: 'drum', name: 'Drum', emoji: '🥁', fact: 'Drums are percussion — you tap or hit them to keep the beat.' },
  { id: 'piano', name: 'Piano', emoji: '🎹', fact: 'A piano has 88 keys. Tiny hammers inside tap the strings!' },
  { id: 'violin', name: 'Violin', emoji: '🎻', fact: 'A violin is played with a bow made of horsehair.' },
  { id: 'trumpet', name: 'Trumpet', emoji: '🎺', fact: 'Trumpet players buzz their lips to make a bright, bold sound.' },
  { id: 'xylophone', name: 'Xylophone', fact: 'Xylophone bars are tapped with mallets. Shorter bars sound higher!' },
]

export function InstrumentArt({ id, size = 72 }: { id: Instrument; size?: number }) {
  if (id === 'clarinet')
    return (
      <svg viewBox="0 0 100 100" width={size} height={size} aria-hidden>
        <g transform="rotate(-35 50 50)">
          <rect x="44" y="6" width="12" height="10" rx="3" fill="#3a2318" />
          <rect x="42" y="14" width="16" height="64" rx="4" fill="#2b1458" />
          <path d="M40 76 L60 76 L68 96 L32 96 Z" fill="#2b1458" />
          {[24, 34, 44, 54, 64].map((y) => (
            <circle key={y} cx="50" cy={y} r="3.5" fill="#ffd23f" />
          ))}
          <rect x="42" y="30" width="3" height="40" fill="#ffffff33" />
        </g>
      </svg>
    )
  if (id === 'xylophone')
    return (
      <svg viewBox="0 0 100 100" width={size} height={size} aria-hidden>
        {['#ff4b5c', '#ff8a3d', '#ffd23f', '#2ed47a', '#3e8bff', '#8a4fff'].map((c, i) => (
          <rect key={c} x={8 + i * 14.5} y={18 + i * 4} width="11" height={70 - i * 8} rx="3" fill={c} />
        ))}
        <line x1="70" y1="10" x2="92" y2="40" stroke="#7a4a32" strokeWidth="4" strokeLinecap="round" />
        <circle cx="70" cy="10" r="6" fill="#ff5fa2" />
      </svg>
    )
  const emoji = INSTRUMENTS.find((i) => i.id === id)?.emoji
  return (
    <span aria-hidden style={{ fontSize: size * 0.85, lineHeight: 1 }}>
      {emoji}
    </span>
  )
}
