import { useMemo, useState } from 'react'
import { Shape } from '../Shape'
import type { ShapeKind } from '../Shape'
import { Prompt, StepPills } from './StepPills'
import type { RoomProps } from './types'
import { centerOf } from './types'
import { COLORS } from '@/lib/game-data'
import { sound } from '@/lib/audio'

const MORPHS: ShapeKind[] = ['heart', 'star', 'circle', 'block']

export function ColorGarden({ burst, onComplete }: RoomProps) {
  const [touched, setTouched] = useState<Set<string>>(new Set())
  const [bouncing, setBouncing] = useState<string | null>(null)
  const [stage, setStage] = useState<'explore' | 'challenge'>('explore')
  const [round, setRound] = useState(0)
  const [morphed, setMorphed] = useState<Record<string, ShapeKind>>({})
  const targets = useMemo(() => {
    const pool = [...COLORS].sort(() => Math.random() - 0.5)
    return pool.slice(0, 3)
  }, [])
  const target = targets[round]

  const tap = (name: string, el: HTMLElement, index: number) => {
    setBouncing(name)
    window.setTimeout(() => setBouncing(null), 560)
    const [x, y] = centerOf(el)
    if (stage === 'explore') {
      sound.note(index)
      sound.say(name)
      burst(x, y, 8)
      const next = new Set(touched).add(name)
      setTouched(next)
      if (next.size === COLORS.length) {
        window.setTimeout(() => {
          setStage('challenge')
          sound.say(`Now, can you find ${targets[0].name}?`)
        }, 1200)
      }
      return
    }
    if (name === target.name) {
      sound.success()
      burst(x, y, 14)
      setMorphed((m) => ({ ...m, [name]: MORPHS[round % MORPHS.length] }))
      sound.say(`Yes! ${name}!`)
      if (round + 1 >= targets.length) {
        window.setTimeout(() => onComplete(3), 1500)
      } else {
        window.setTimeout(() => {
          setRound(round + 1)
          sound.say(`Can you find ${targets[round + 1].name}?`)
        }, 1500)
      }
    } else {
      // Toddler mode: there are no wrong answers, just gentle redirection.
      sound.pop()
      sound.say(`That's ${name}! Let's find ${target.name}.`)
    }
  }

  return (
    <div className="space-y-5">
      <StepPills current={stage === 'explore' ? 'Explore' : 'Challenge'} />
      <Prompt>
        {stage === 'explore' ? (
          <>Touch every balloon! 🎈 ({touched.size}/{COLORS.length})</>
        ) : (
          <>
            Find <span style={{ color: target.hex }} className="drop-shadow-[0_1px_0_#0002]">{target.name}</span>!
          </>
        )}
      </Prompt>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 sm:gap-6">
        {COLORS.map((c, i) => {
          const morph = morphed[c.name]
          return (
            <button
              key={c.name}
              type="button"
              onClick={(e) => tap(c.name, e.currentTarget, i)}
              aria-label={`${c.name} balloon`}
              className="group relative flex flex-col items-center rounded-[2rem] bg-white/60 p-4 focus-visible:ring-4 focus-visible:ring-g-purple focus-visible:outline-none"
            >
              <span
                className={`anim-float block ${bouncing === c.name ? 'anim-boing' : ''}`}
                style={{ ['--r' as string]: `${(i % 2 ? 1 : -1) * 3}deg`, animationDelay: `${i * -0.7}s` }}
              >
                {morph ? (
                  <Shape kind={morph} color={c.hex} size={120} className="anim-twirl-in" />
                ) : (
                  <svg viewBox="0 0 100 140" width="110" height="154" aria-hidden>
                    <ellipse cx="50" cy="52" rx="40" ry="48" fill={c.hex} stroke="#0002" strokeWidth="3" />
                    <ellipse cx="36" cy="34" rx="9" ry="14" fill="#fff" opacity="0.5" />
                    <path d="M44 99 L56 99 L50 108 Z" fill={c.hex} />
                    <path d="M50 108 Q42 122 52 138" stroke="#0004" strokeWidth="2" fill="none" />
                  </svg>
                )}
              </span>
              <span className="mt-1 text-xl font-bold" style={{ color: c.hex }}>
                {touched.has(c.name) || stage === 'challenge' ? c.name : '?'}
              </span>
              {touched.has(c.name) && stage === 'explore' && (
                <span aria-hidden className="absolute top-2 right-3 text-2xl">✨</span>
              )}
            </button>
          )
        })}
      </div>
    </div>
  )
}
