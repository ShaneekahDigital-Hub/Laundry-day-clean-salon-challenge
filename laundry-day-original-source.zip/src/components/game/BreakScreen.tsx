import { useState } from 'react'
import { Link } from '@tanstack/react-router'
import { Avatar } from './Avatar'
import { useGame } from './GameProvider'
import { GrownUpGate } from './GrownUpGate'

/** Daily stopping point: shown when the caregiver's play duration is up, or when a child picks "Take a break". */
export function BreakScreen({ onKeepPlaying }: { onKeepPlaying?: () => void }) {
  const { stars, progress, extendPlay, breakDue } = useGame()
  const [gate, setGate] = useState(false)
  const rooms = Object.keys(progress.rooms).length

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="break-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#2b1458cc] p-4 backdrop-blur-sm"
    >
      <div className="game-card anim-pop-in w-full max-w-md p-6 text-center sm:p-8">
        <Avatar size={110} className="mx-auto" />
        <h2 id="break-title" className="mt-2 text-3xl font-bold text-g-purple">
          Time for a little break!
        </h2>
        <p className="mt-2 text-lg">
          You did amazing today. Your <strong>{stars} stars</strong> and {rooms} finished{' '}
          {rooms === 1 ? 'room are' : 'rooms are'} saved for next time. 💖
        </p>
        <p className="mt-1 text-sm text-g-ink/70">Stretch, get a drink of water, and come back another day.</p>
        <div className="mt-6 flex flex-col gap-3">
          <Link to="/" className="chunky-btn bg-g-pink px-6 py-3 text-lg text-white">
            See you next time 👋
          </Link>
          {gate ? (
            <div className="rounded-2xl bg-muted p-4 font-sans text-foreground">
              <GrownUpGate
                reason="Grown-ups: answer to allow 10 more minutes."
                onPass={() => {
                  if (breakDue) extendPlay(10)
                  onKeepPlaying?.()
                  setGate(false)
                }}
              />
            </div>
          ) : (
            <button
              type="button"
              onClick={() => (breakDue ? setGate(true) : onKeepPlaying?.())}
              className="text-sm font-semibold text-g-purple underline underline-offset-4"
            >
              {breakDue ? 'Grown-up: allow 10 more minutes' : 'Keep playing'}
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
