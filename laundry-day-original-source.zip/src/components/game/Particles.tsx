import { useCallback, useEffect, useRef, useState } from 'react'
import { useGame } from './GameProvider'

const GLYPHS = ['★', '♥', '✦', '●', '◆', '✿']
const COLORS = ['#ff5fa2', '#ffd23f', '#8a4fff', '#2ed47a', '#3ec5ff', '#ff8a3d']

interface Particle {
  id: number
  x: number
  y: number
  dx: number
  dy: number
  rot: number
  glyph: string
  color: string
  size: number
  dur: number
}

let nextId = 0

/**
 * Celebration bursts of stars and hearts. Gentle mode (toddlers / calm motion)
 * uses fewer, slower particles.
 */
export function useParticles(gentle = false) {
  const { settings } = useGame()
  const [particles, setParticles] = useState<Particle[]>([])
  const ref = useRef<HTMLDivElement>(null)
  const soft = gentle || settings.calmMotion

  const burst = useCallback(
    (clientX?: number, clientY?: number, amount = 14) => {
      const box = ref.current?.getBoundingClientRect()
      if (!box) return
      const x = clientX !== undefined ? clientX - box.left : box.width / 2
      const y = clientY !== undefined ? clientY - box.top : box.height / 2
      const count = soft ? Math.ceil(amount / 2) : amount
      const fresh: Particle[] = Array.from({ length: count }, (_, i) => {
        const angle = (Math.PI * 2 * i) / count + Math.random() * 0.5
        const dist = (soft ? 50 : 80) + Math.random() * (soft ? 40 : 90)
        return {
          id: nextId++,
          x,
          y,
          dx: Math.cos(angle) * dist,
          dy: Math.sin(angle) * dist - (soft ? 10 : 30),
          rot: Math.random() * 360 - 180,
          glyph: GLYPHS[i % GLYPHS.length],
          color: COLORS[(i + Math.floor(Math.random() * 6)) % COLORS.length],
          size: 16 + Math.random() * 18,
          dur: soft ? 1400 : 900 + Math.random() * 300,
        }
      })
      setParticles((p) => [...p.slice(-60), ...fresh])
      const ids = new Set(fresh.map((f) => f.id))
      window.setTimeout(
        () => setParticles((p) => p.filter((q) => !ids.has(q.id))),
        soft ? 1500 : 1300,
      )
    },
    [soft],
  )

  const layer = (
    <div ref={ref} aria-hidden className="pointer-events-none absolute inset-0 z-40 overflow-hidden">
      {particles.map((p) => (
        <span
          key={p.id}
          className="particle"
          style={
            {
              left: p.x,
              top: p.y,
              color: p.color,
              fontSize: p.size,
              '--dx': `${p.dx}px`,
              '--dy': `${p.dy}px`,
              '--rot': `${p.rot}deg`,
              '--dur': `${p.dur}ms`,
            } as React.CSSProperties
          }
        >
          {p.glyph}
        </span>
      ))}
    </div>
  )

  return { burst, layer }
}

/** A light sparkle trail that follows fingers and mice in the game world. */
export function SparkleTrail({ enabled }: { enabled: boolean }) {
  useEffect(() => {
    if (!enabled) return
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    let last = 0
    let live = 0
    const onMove = (e: PointerEvent) => {
      const now = performance.now()
      if (now - last < 45 || live > 16) return
      last = now
      const el = document.createElement('span')
      el.className = 'trail'
      el.textContent = Math.random() > 0.5 ? '✦' : '★'
      el.style.left = `${e.clientX}px`
      el.style.top = `${e.clientY}px`
      el.style.color = COLORS[Math.floor(Math.random() * COLORS.length)]
      el.style.fontSize = `${12 + Math.random() * 10}px`
      live++
      el.addEventListener('animationend', () => {
        el.remove()
        live--
      })
      document.body.appendChild(el)
    }
    window.addEventListener('pointermove', onMove, { passive: true })
    return () => window.removeEventListener('pointermove', onMove)
  }, [enabled])
  return null
}

/** Hearts and stars slowly orbiting a point: decorative only. */
export function Whirlers({ count = 6, orbit = 140, className = '' }: { count?: number; orbit?: number; className?: string }) {
  return (
    <div aria-hidden className={`pointer-events-none absolute inset-0 flex items-center justify-center ${className}`}>
      {Array.from({ length: count }, (_, i) => (
        <span
          key={i}
          className="absolute text-2xl motion-reduce:hidden [[data-calm=true]_&]:hidden"
          style={
            {
              '--orbit': `${orbit + (i % 2) * 24}px`,
              color: COLORS[i % COLORS.length],
              animation: `whirl ${14 + i * 1.5}s linear infinite`,
              animationDelay: `${-i * 2.2}s`,
            } as React.CSSProperties
          }
        >
          {i % 2 ? '♥' : '★'}
        </span>
      ))}
    </div>
  )
}
