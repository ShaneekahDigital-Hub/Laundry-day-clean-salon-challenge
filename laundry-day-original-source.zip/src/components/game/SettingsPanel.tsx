import { useId } from 'react'
import { Volume1, Volume2, VolumeX } from 'lucide-react'
import { useGame } from './GameProvider'
import type { Settings } from './GameProvider'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { sound } from '@/lib/audio'

const DURATIONS = [0, 10, 15, 20, 30, 45]

function Toggle({
  label,
  hint,
  field,
}: {
  label: string
  hint: string
  field: keyof Pick<Settings, 'sfx' | 'music' | 'voice' | 'movement' | 'calmMotion' | 'muted'>
}) {
  const id = useId()
  const { settings, updateSettings } = useGame()
  return (
    <div className="flex items-start justify-between gap-4 py-3">
      <div>
        <Label htmlFor={id} className="text-sm font-semibold">
          {label}
        </Label>
        <p className="text-xs text-muted-foreground">{hint}</p>
      </div>
      <Switch
        id={id}
        checked={settings[field]}
        onCheckedChange={(v) => updateSettings({ [field]: v })}
      />
    </div>
  )
}

export function SettingsPanel() {
  const { settings, updateSettings } = useGame()
  const volId = useId()
  const durId = useId()
  const VolIcon = settings.muted || settings.volume === 0 ? VolumeX : settings.volume < 0.5 ? Volume1 : Volume2

  return (
    <div className="divide-y divide-border">
      <div className="pb-4">
        <Label htmlFor={volId} className="text-sm font-semibold">
          Volume
        </Label>
        <div className="mt-2 flex items-center gap-3">
          <VolIcon aria-hidden className="size-5 text-rose" />
          <input
            id={volId}
            type="range"
            min={0}
            max={100}
            step={5}
            value={Math.round(settings.volume * 100)}
            onChange={(e) => updateSettings({ volume: Number(e.target.value) / 100 })}
            onPointerUp={() => sound.pop()}
            onKeyUp={() => sound.pop()}
            className="h-2 w-full cursor-pointer accent-[var(--rose)]"
            aria-valuetext={`${Math.round(settings.volume * 100)} percent`}
          />
          <span className="w-10 text-right text-xs tabular-nums text-muted-foreground">
            {Math.round(settings.volume * 100)}%
          </span>
        </div>
      </div>
      <Toggle field="muted" label="Mute everything" hint="Silences all sounds, music, and voices." />
      <Toggle field="sfx" label="Sound feedback" hint="Pops, sparkles, and animal sounds when objects are touched." />
      <Toggle field="music" label="Music" hint="The clarinet melody and musical moments." />
      <Toggle field="voice" label="Spoken words" hint="Reads names of colors, shapes, and animals aloud." />
      <Toggle field="movement" label="Movement activities" hint="Shows the Movement Magic Ladder doors. Always supervise." />
      <Toggle field="calmMotion" label="Calm motion" hint="Fewer, slower animations and no sparkle trail." />
      <div className="pt-4">
        <Label htmlFor={durId} className="text-sm font-semibold">
          Play duration
        </Label>
        <p className="text-xs text-muted-foreground">A gentle break reminder appears after this much play. Progress is always saved.</p>
        <select
          id={durId}
          value={settings.sessionMinutes}
          onChange={(e) => updateSettings({ sessionMinutes: Number(e.target.value) })}
          className="mt-2 w-full rounded-lg border border-input bg-card px-3 py-2 text-sm focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
        >
          {DURATIONS.map((m) => (
            <option key={m} value={m}>
              {m === 0 ? 'No reminder' : `${m} minutes`}
            </option>
          ))}
        </select>
      </div>
    </div>
  )
}
