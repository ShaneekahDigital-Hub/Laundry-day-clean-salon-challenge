import { Link } from '@tanstack/react-router'
import { useEffect, useState } from 'react'
import { Award, Check, Printer, RotateCcw, Star } from 'lucide-react'
import { Avatar } from './Avatar'
import { Certificate } from './Certificate'
import { useGame } from './GameProvider'
import type { CompletionResult } from './GameProvider'
import { UpgradeInvite } from './UpgradeInvite'
import { BreakScreen } from './BreakScreen'
import { Whirlers } from './Particles'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { demoFinished, doorState, roomsFor } from '@/lib/game-data'
import type { Room } from '@/lib/game-data'
import { sound } from '@/lib/audio'

export function Celebration({
  room,
  result,
  onReplay,
}: {
  room: Room
  result: CompletionResult
  onReplay: () => void
}) {
  const { access, progress, settings, setExplorerName } = useGame()
  const [shown, setShown] = useState(0)
  const [cert, setCert] = useState(false)
  const [resting, setResting] = useState(false)

  useEffect(() => {
    sound.celebrate()
    sound.say(result.stars === 3 ? 'Amazing! Three stars!' : 'You did it!')
    const timers = [1, 2, 3].map((n) =>
      window.setTimeout(() => {
        setShown(n)
        if (n <= result.stars) sound.note(n + 1)
      }, 350 * n + 300),
    )
    return () => timers.forEach(window.clearTimeout)
  }, [result.stars])

  const siblings = roomsFor(room.mode)
  const next = siblings
    .slice(siblings.indexOf(room) + 1)
    .concat(siblings.slice(0, siblings.indexOf(room)))
    .find((r) => doorState(r, access.tier, progress, settings.movement) === 'open' && !progress.rooms[r.id])
  const newlyOpened = result.unlockedDoors.filter(
    (r) => doorState(r, access.tier, progress, settings.movement) === 'open',
  )
  const showInvite = access.tier === 'demo' && demoFinished(progress, room.mode, settings.movement)

  return (
    <div className="anim-room-enter relative mx-auto max-w-2xl px-4 pt-4 pb-16">
      <div className="game-card relative overflow-hidden p-6 text-center sm:p-8">
        <Whirlers count={8} orbit={170} className="opacity-70" />
        <Avatar size={120} className="anim-float relative mx-auto" />
        <p className="relative text-sm font-bold tracking-widest text-g-pink uppercase">Room complete</p>
        <h1 className="relative text-4xl font-bold text-g-purple sm:text-5xl">You did it! 🎉</h1>
        <p className="relative mt-1 text-lg">{room.title}</p>

        <div className="relative mt-5 flex justify-center gap-3" aria-label={`${result.stars} of 3 stars earned`}>
          {[1, 2, 3].map((n) => (
            <Star
              key={n}
              aria-hidden
              className={`size-16 transition-all duration-300 sm:size-20 ${
                shown >= n
                  ? n <= result.stars
                    ? 'anim-twirl-in fill-g-yellow text-[#e0a800]'
                    : 'fill-g-ink/10 text-g-ink/20'
                  : 'scale-50 opacity-0'
              }`}
            />
          ))}
        </div>

        <div className="relative mt-6 grid gap-3 text-left sm:grid-cols-2">
          <div className="rounded-2xl bg-[#fff3fa] p-4">
            <p className="text-xs font-bold tracking-wide text-g-pink uppercase">Explorer badge</p>
            <p className="mt-1 flex items-center gap-2 text-xl font-bold">
              <Award aria-hidden className="size-6 text-g-purple" /> {result.badge}
            </p>
          </div>
          <div className="rounded-2xl bg-[#effcf5] p-4">
            <p className="text-xs font-bold tracking-wide text-[#18a35a] uppercase">Activity status</p>
            <ul className="mt-1 space-y-0.5 text-base font-semibold">
              {['Explored the room', 'Finished the challenge', 'Progress saved'].map((s) => (
                <li key={s} className="flex items-center gap-2">
                  <Check aria-hidden className="size-5 text-g-green" strokeWidth={3} /> {s}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {(result.newAccessories.length > 0 || newlyOpened.length > 0) && (
          <div className="relative mt-3 rounded-2xl bg-[#fff8dc] p-4 text-left">
            <p className="text-xs font-bold tracking-wide text-[#b07d00] uppercase">New rewards!</p>
            <ul className="mt-1 space-y-1 text-lg font-semibold">
              {result.newAccessories.map((a) => (
                <li key={a.id} className="anim-pop-in">
                  {a.emoji} {a.name} — wear it in My Rewards!
                </li>
              ))}
              {newlyOpened.map((r) => (
                <li key={r.id} className="anim-pop-in">
                  🗝️ The secret {r.title} door is open!
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="relative mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:justify-center">
          {next ? (
            <Link
              to="/play/$mode/$roomId"
              params={{ mode: next.mode, roomId: next.id }}
              className="chunky-btn bg-g-pink px-6 py-3 text-lg text-white"
            >
              Keep going: {next.icon} {next.title}
            </Link>
          ) : (
            <Link to="/play/$mode" params={{ mode: room.mode }} className="chunky-btn bg-g-pink px-6 py-3 text-lg text-white">
              Back to the hallway
            </Link>
          )}
          <button type="button" onClick={() => setResting(true)} className="chunky-btn bg-g-blue px-6 py-3 text-lg text-white">
            Take a break
          </button>
        </div>
        <div className="relative mt-4 flex flex-wrap justify-center gap-4 text-sm font-semibold text-g-purple">
          <button type="button" onClick={onReplay} className="flex items-center gap-1 underline-offset-4 hover:underline">
            <RotateCcw aria-hidden className="size-4" /> Play again
          </button>
          <button type="button" onClick={() => setCert(true)} className="flex items-center gap-1 underline-offset-4 hover:underline">
            <Printer aria-hidden className="size-4" /> Get my certificate
          </button>
          {next && (
            <Link to="/play/$mode" params={{ mode: room.mode }} className="underline-offset-4 hover:underline">
              Hallway
            </Link>
          )}
        </div>
      </div>

      {showInvite && (
        <div className="mt-6">
          <UpgradeInvite />
        </div>
      )}

      <Dialog open={cert} onOpenChange={setCert}>
        <DialogContent className="bg-background sm:max-w-xl">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl">Room-completion certificate</DialogTitle>
            <DialogDescription>Add the explorer’s first name, then print or save it.</DialogDescription>
          </DialogHeader>
          <label className="text-sm font-semibold" htmlFor="cert-name">
            Explorer’s first name
          </label>
          <input
            id="cert-name"
            value={progress.explorerName}
            maxLength={24}
            onChange={(e) => setExplorerName(e.target.value)}
            className="rounded-lg border border-input bg-card px-3 py-2"
            placeholder="First name"
          />
          <div className="print-area">
            <Certificate room={room} name={progress.explorerName} date={progress.rooms[room.id]?.completedAt} />
          </div>
          <button
            type="button"
            onClick={() => window.print()}
            className="flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-3 font-semibold text-primary-foreground hover:bg-rose-deep"
          >
            <Printer aria-hidden className="size-4" /> Print certificate
          </button>
        </DialogContent>
      </Dialog>

      {resting && <BreakScreen onKeepPlaying={() => setResting(false)} />}
    </div>
  )
}
