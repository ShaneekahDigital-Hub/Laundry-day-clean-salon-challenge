import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react'
import { sound } from '@/lib/audio'
import type { RoomId, Tier } from '@/lib/game-data'
import { ACCESSORIES, ROOMS, getRoom, modeStars } from '@/lib/game-data'
import type { Progress } from '@/lib/progress'
import {
  emptyProgress,
  mergeProgress,
  progressSchema,
  totalStars,
} from '@/lib/progress'

export interface Settings {
  volume: number
  muted: boolean
  sfx: boolean
  music: boolean
  voice: boolean
  movement: boolean
  calmMotion: boolean
  /** Minutes of play before a break reminder. 0 turns it off. */
  sessionMinutes: number
}

const DEFAULT_SETTINGS: Settings = {
  volume: 0.7,
  muted: false,
  sfx: true,
  music: true,
  voice: true,
  movement: true,
  calmMotion: false,
  sessionMinutes: 20,
}

const SETTINGS_KEY = 'sbl-settings'
const PROGRESS_KEY = 'sbl-progress'

export interface Access {
  status: 'loading' | 'ready'
  tier: Tier
  email?: string
}

export interface CompletionResult {
  stars: number
  bestStars: number
  firstTime: boolean
  badge: string
  newAccessories: typeof ACCESSORIES
  /** Bonus doors that this completion just unlocked. */
  unlockedDoors: typeof ROOMS
}

interface GameContextValue {
  hydrated: boolean
  settings: Settings
  updateSettings: (patch: Partial<Settings>) => void
  progress: Progress
  stars: number
  completeRoom: (id: RoomId, stars: number) => CompletionResult
  toggleAccessory: (id: string) => void
  setExplorerName: (name: string) => void
  access: Access
  redeem: (email: string, orderId: string) => Promise<void>
  signOut: () => Promise<void>
  /** Break reminder state for the caregiver play-duration control. */
  breakDue: boolean
  playing: boolean
  setPlaying: (playing: boolean) => void
  extendPlay: (minutes: number) => void
  syncState: 'idle' | 'saving' | 'saved' | 'offline'
}

const stamp = (p: Progress): Progress => ({ ...p, updatedAt: new Date().toISOString() })

const GameContext = createContext<GameContextValue | null>(null)

function readJSON<T>(key: string): T | null {
  try {
    const raw = window.localStorage.getItem(key)
    return raw ? (JSON.parse(raw) as T) : null
  } catch {
    return null
  }
}

export function GameProvider({ children }: { children: React.ReactNode }) {
  const [hydrated, setHydrated] = useState(false)
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS)
  const [progress, setProgress] = useState<Progress>(emptyProgress)
  const [access, setAccess] = useState<Access>({ status: 'loading', tier: 'none' })
  const [syncState, setSyncState] = useState<GameContextValue['syncState']>('idle')
  const [playing, setPlaying] = useState(false)
  const [playedMs, setPlayedMs] = useState(0)
  const [limitMs, setLimitMs] = useState<number | null>(null)
  const dirty = useRef(false)

  // Load saved settings and progress after hydration (localStorage is browser-only).
  useEffect(() => {
    const savedSettings = readJSON<Partial<Settings>>(SETTINGS_KEY)
    if (savedSettings) setSettings((s) => ({ ...s, ...savedSettings }))
    const parsed = progressSchema.safeParse(readJSON(PROGRESS_KEY))
    const local = parsed.success ? parsed.data : emptyProgress()
    setProgress(local)
    setHydrated(true)

    fetch('/api/access', { credentials: 'same-origin' })
      .then((r) => (r.ok ? r.json() : { tier: 'none' }))
      .then((data: { tier: Tier; email?: string; progress?: unknown }) => {
        setAccess({ status: 'ready', tier: data.tier, email: data.email })
        const server = progressSchema.safeParse(data.progress)
        if (server.success) {
          setProgress((p) => mergeProgress(p, server.data))
          dirty.current = true
        }
      })
      .catch(() => setAccess({ status: 'ready', tier: 'none' }))
  }, [])

  useEffect(() => {
    sound.configure(settings)
    if (hydrated) window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings))
  }, [settings, hydrated])

  useEffect(() => {
    if (hydrated) document.documentElement.dataset.calm = settings.calmMotion ? 'true' : 'false'
  }, [settings.calmMotion, hydrated])

  // Save progress locally right away, and to the family's account shortly after.
  useEffect(() => {
    if (!hydrated) return
    window.localStorage.setItem(PROGRESS_KEY, JSON.stringify(progress))
    if (access.tier === 'none' || !dirty.current) return
    setSyncState('saving')
    const timer = window.setTimeout(() => {
      fetch('/api/progress', {
        method: 'PUT',
        credentials: 'same-origin',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(progress),
      })
        .then((r) => {
          setSyncState(r.ok ? 'saved' : 'offline')
          if (r.ok) dirty.current = false
        })
        .catch(() => setSyncState('offline'))
    }, 800)
    return () => window.clearTimeout(timer)
  }, [progress, hydrated, access.tier])

  // Play-duration clock: only counts while a game screen is open and visible.
  useEffect(() => {
    if (!playing || settings.sessionMinutes === 0) return
    const id = window.setInterval(() => {
      if (document.visibilityState === 'visible') setPlayedMs((ms) => ms + 5000)
    }, 5000)
    return () => window.clearInterval(id)
  }, [playing, settings.sessionMinutes])

  const effectiveLimit = limitMs ?? settings.sessionMinutes * 60_000
  const breakDue =
    playing && settings.sessionMinutes > 0 && playedMs >= effectiveLimit

  const extendPlay = useCallback(
    (minutes: number) => setLimitMs(playedMs + minutes * 60_000),
    [playedMs],
  )

  const completeRoom = useCallback(
    (id: RoomId, earned: number): CompletionResult => {
      const prev = progress.rooms[id]
      const before = totalStars(progress)
      const bestStars = Math.max(prev?.stars ?? 0, earned)
      dirty.current = true
      const next: Progress = stamp({
        ...progress,
        rooms: {
          ...progress.rooms,
          [id]: {
            stars: bestStars,
            times: (prev?.times ?? 0) + 1,
            completedAt: prev?.completedAt ?? new Date().toISOString(),
          },
        },
      })
      const after = totalStars(next)
      setProgress(next)
      return {
        stars: earned,
        bestStars,
        firstTime: !prev,
        badge: getRoom(id)?.badge ?? 'Explorer',
        newAccessories: ACCESSORIES.filter((a) => a.stars > before && a.stars <= after),
        unlockedDoors: ROOMS.filter(
          (r) =>
            r.unlockStars &&
            modeStars(progress, r.mode) < r.unlockStars &&
            modeStars(next, r.mode) >= r.unlockStars,
        ),
      }
    },
    [progress],
  )

  const toggleAccessory = useCallback((id: string) => {
    dirty.current = true
    setProgress((p) =>
      stamp({
        ...p,
        equipped: p.equipped.includes(id)
          ? p.equipped.filter((e) => e !== id)
          : [...p.equipped, id],
      }),
    )
  }, [])

  const setExplorerName = useCallback((name: string) => {
    dirty.current = true
    setProgress((p) => stamp({ ...p, explorerName: name.slice(0, 24) }))
  }, [])

  const redeem = useCallback(async (email: string, orderId: string) => {
    const res = await fetch('/api/access/redeem', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ email, orderId }),
    })
    const data = (await res.json().catch(() => ({}))) as {
      tier?: Tier
      email?: string
      progress?: unknown
      error?: string
    }
    if (!res.ok || !data.tier) throw new Error(data.error ?? 'Something went wrong. Please try again.')
    setAccess({ status: 'ready', tier: data.tier, email: data.email })
    const server = progressSchema.safeParse(data.progress)
    dirty.current = true
    setProgress((p) => {
      const merged = server.success ? mergeProgress(p, server.data) : p
      return { ...merged, updatedAt: new Date().toISOString() }
    })
  }, [])

  const signOut = useCallback(async () => {
    await fetch('/api/access', { method: 'DELETE', credentials: 'same-origin' }).catch(() => {})
    setAccess({ status: 'ready', tier: 'none' })
    setSyncState('idle')
  }, [])

  const updateSettings = useCallback((patch: Partial<Settings>) => {
    setSettings((s) => ({ ...s, ...patch }))
    if ('sessionMinutes' in patch) {
      setPlayedMs(0)
      setLimitMs(null)
    }
  }, [])

  const value = useMemo<GameContextValue>(
    () => ({
      hydrated,
      settings,
      updateSettings,
      progress,
      stars: totalStars(progress),
      completeRoom,
      toggleAccessory,
      setExplorerName,
      access,
      redeem,
      signOut,
      breakDue,
      playing,
      setPlaying,
      extendPlay,
      syncState,
    }),
    [hydrated, settings, updateSettings, progress, completeRoom, toggleAccessory, setExplorerName, access, redeem, signOut, breakDue, playing, extendPlay, syncState],
  )

  return <GameContext.Provider value={value}>{children}</GameContext.Provider>
}

export function useGame() {
  const ctx = useContext(GameContext)
  if (!ctx) throw new Error('useGame must be used inside GameProvider')
  return ctx
}
