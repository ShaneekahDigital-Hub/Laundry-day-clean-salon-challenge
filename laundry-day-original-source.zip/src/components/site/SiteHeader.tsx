import { Link } from '@tanstack/react-router'
import { Heart, Menu, Sparkles, Star } from 'lucide-react'
import { useState } from 'react'
import { Brand } from './Brand'
import { useGame } from '@/components/game/GameProvider'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'

const NAV = [
  { to: '/play', label: 'Learn & Play' },
  { to: '/collection', label: 'Our Collection' },
  { to: '/grown-ups', label: 'For Grown-Ups' },
] as const

const linkClass =
  'border-b-2 border-transparent py-2 text-[13px] font-semibold text-foreground transition-colors hover:text-rose focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm motion-reduce:transition-none'
const activeClass = 'border-rose text-rose'

export function SiteHeader() {
  const { stars, hydrated } = useGame()
  const [open, setOpen] = useState(false)

  return (
    <>
      <div className="flex h-[33px] items-center justify-center gap-2 bg-rose px-4 text-center text-[11px] tracking-[0.6px] text-primary-foreground">
        <Sparkles aria-hidden className="size-3" />
        Little lessons. Big confidence. A whole lot of sparkle.
        <Heart aria-hidden className="size-3" />
      </div>
      <header className="mx-auto flex min-h-[88px] max-w-[1240px] items-center gap-4 px-5 py-4 sm:px-9 md:gap-9 md:min-h-[100px]">
        <Brand />
        <nav aria-label="Main" className="ml-auto hidden items-center gap-7 md:flex">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={linkClass}
              activeProps={{ className: activeClass }}
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <Link
          to="/rewards"
          className="ml-auto flex items-center gap-2 rounded-lg border border-input px-3 py-2 text-xs font-semibold transition-colors hover:bg-muted focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none md:ml-0 motion-reduce:transition-none"
        >
          <Star aria-hidden className="size-4 fill-butter text-gold" />
          My Rewards
          <span className="rounded-full bg-muted px-2 py-0.5 text-[10px]" aria-label={`${stars} stars`}>
            {hydrated ? stars : 0}
          </span>
        </Link>
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger
            className="rounded-md p-2 focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none md:hidden"
            aria-label="Open navigation menu"
          >
            <Menu aria-hidden className="size-6" />
          </SheetTrigger>
          <SheetContent side="right" className="bg-background">
            <SheetHeader>
              <SheetTitle className="font-display text-2xl">Menu</SheetTitle>
              <SheetDescription>Where shall we go next?</SheetDescription>
            </SheetHeader>
            <nav aria-label="Mobile" className="flex flex-col gap-2 px-4">
              {[...NAV, { to: '/rewards', label: 'My Rewards' } as const].map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={() => setOpen(false)}
                  className="rounded-lg px-3 py-3 text-base font-semibold hover:bg-muted"
                  activeProps={{ className: 'bg-secondary text-rose' }}
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          </SheetContent>
        </Sheet>
      </header>
    </>
  )
}
