import { Link } from '@tanstack/react-router'
import { Brand } from './Brand'

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-[#fffaf4]">
      <div className="mx-auto flex max-w-content flex-col gap-6 px-4 py-10 sm:px-6 md:flex-row md:items-center md:justify-between">
        <Brand compact />
        <nav aria-label="Footer" className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted-foreground">
          <Link to="/play" className="hover:text-rose">Learn &amp; Play</Link>
          <Link to="/collection" className="hover:text-rose">Our Collection</Link>
          <Link to="/grown-ups" className="hover:text-rose">For Grown-Ups</Link>
          <Link to="/rewards" className="hover:text-rose">My Rewards</Link>
          <Link to="/unlock" className="hover:text-rose">Unlock a purchase</Link>
        </nav>
        <p className="font-script text-2xl text-rose">a little care makes a big difference ♡</p>
      </div>
    </footer>
  )
}
