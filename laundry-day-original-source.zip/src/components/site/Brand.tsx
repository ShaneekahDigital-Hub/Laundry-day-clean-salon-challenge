import { Link } from '@tanstack/react-router'
import { Crown } from 'lucide-react'

export function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <Link
      to="/"
      aria-label="Shaneekah Braids and Locs, The Learning Collection home"
      className="relative flex items-center gap-3 rounded-md text-foreground no-underline focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
    >
      <Crown
        aria-hidden
        className="absolute -top-3 left-10 size-[18px] -rotate-12 text-gold"
      />
      <span className="text-center font-script text-[34px] leading-[0.95] text-rose sm:text-[39px]">
        Shaneekah
        <span className="block pt-2 font-sans text-[8px] font-bold tracking-[3px] text-foreground sm:text-[9px]">
          BRAIDS &amp; LOCS
        </span>
      </span>
      {!compact && (
        <>
          <span aria-hidden className="hidden h-8 w-px bg-[#ddccc3] md:block" />
          <span className="hidden text-[10px] leading-[1.7] tracking-[1.1px] uppercase md:block">
            the learning
            <br />
            collection
          </span>
        </>
      )}
    </Link>
  )
}
