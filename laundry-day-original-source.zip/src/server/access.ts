import { createHash, randomBytes, timingSafeEqual } from 'node:crypto'
import { eq } from 'drizzle-orm'
import { db } from '../../db/index.js'
import { accessSessions, explorerProgress, purchases } from '../../db/schema.js'
import type { Tier } from '@/lib/game-data'
import { emptyProgress, mergeProgress, progressSchema } from '@/lib/progress'
import type { Progress } from '@/lib/progress'

export const COOKIE_NAME = 'sbl_access'
const ONE_YEAR = 60 * 60 * 24 * 365

export const normalizeEmail = (email: string) => email.trim().toLowerCase()
export const normalizeOrder = (order: string) =>
  order.trim().replace(/^#/, '').toUpperCase()

const hashToken = (token: string) =>
  createHash('sha256').update(token).digest('hex')

export function safeEqual(a: string, b: string) {
  const ab = Buffer.from(a)
  const bb = Buffer.from(b)
  return ab.length === bb.length && timingSafeEqual(ab, bb)
}

function readCookie(request: Request, name: string) {
  const header = request.headers.get('cookie') ?? ''
  for (const part of header.split(';')) {
    const [k, ...v] = part.trim().split('=')
    if (k === name) return decodeURIComponent(v.join('='))
  }
  return null
}

export function sessionCookie(token: string) {
  return `${COOKIE_NAME}=${token}; Path=/; Max-Age=${ONE_YEAR}; HttpOnly; Secure; SameSite=Lax`
}
export const clearedCookie = `${COOKIE_NAME}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax`

export async function tierForEmail(email: string): Promise<Tier> {
  const rows = await db
    .select({ tier: purchases.tier })
    .from(purchases)
    .where(eq(purchases.email, email))
  if (rows.some((r) => r.tier === 'full')) return 'full'
  if (rows.some((r) => r.tier === 'demo')) return 'demo'
  return 'none'
}

export async function createSession(email: string) {
  const token = randomBytes(32).toString('base64url')
  await db.insert(accessSessions).values({ tokenHash: hashToken(token), email })
  return token
}

/** Returns the purchasing email for the request's access cookie, if valid. */
export async function sessionEmail(request: Request) {
  const token = readCookie(request, COOKIE_NAME)
  if (!token || token.length > 100) return null
  const [row] = await db
    .select({ email: accessSessions.email })
    .from(accessSessions)
    .where(eq(accessSessions.tokenHash, hashToken(token)))
    .limit(1)
  return row?.email ?? null
}

export async function endSession(request: Request) {
  const token = readCookie(request, COOKIE_NAME)
  if (token)
    await db
      .delete(accessSessions)
      .where(eq(accessSessions.tokenHash, hashToken(token)))
}

export async function loadProgress(email: string): Promise<Progress> {
  const [row] = await db
    .select({ progress: explorerProgress.progress })
    .from(explorerProgress)
    .where(eq(explorerProgress.email, email))
    .limit(1)
  const parsed = progressSchema.safeParse(row?.progress)
  return parsed.success ? parsed.data : emptyProgress()
}

export async function saveProgress(email: string, incoming: Progress) {
  const merged = mergeProgress(await loadProgress(email), incoming)
  await db
    .insert(explorerProgress)
    .values({ email, progress: merged })
    .onConflictDoUpdate({
      target: explorerProgress.email,
      set: { progress: merged, updatedAt: new Date() },
    })
  return merged
}

export function maskEmail(email: string) {
  const [user, domain] = email.split('@')
  return `${user.slice(0, 2)}${'•'.repeat(Math.max(1, user.length - 2))}@${domain}`
}

export async function recordPurchase(p: {
  orderRef: string
  receiptRef?: string | null
  email: string
  tier: 'demo' | 'full'
}) {
  await db
    .insert(purchases)
    .values({
      orderRef: normalizeOrder(p.orderRef),
      receiptRef: p.receiptRef ? normalizeOrder(p.receiptRef) : null,
      email: normalizeEmail(p.email),
      tier: p.tier,
    })
    .onConflictDoNothing({ target: purchases.orderRef })
}
