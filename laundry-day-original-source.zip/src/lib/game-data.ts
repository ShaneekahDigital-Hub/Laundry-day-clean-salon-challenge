import type { Progress } from './progress'
import { totalStars } from './progress'

export type Mode = 'little' | 'big'
export type Tier = 'none' | 'demo' | 'full'

export const MODES: Record<
  Mode,
  { title: string; ages: string; tagline: string; color: string }
> = {
  little: {
    title: 'Little Explorers',
    ages: 'Ages 0–2',
    tagline: 'Gentle, grown-up guided discovery',
    color: '#ff6fae',
  },
  big: {
    title: 'Big Explorers',
    ages: 'Ages 6–8',
    tagline: 'Puzzles, trivia, and challenges',
    color: '#7b3fe4',
  },
}

export type RoomId =
  | 'color-garden'
  | 'shape-parade'
  | 'animal-friends'
  | 'sparkle-music'
  | 'little-movement'
  | 'laundry-day'
  | 'clean-salon'
  | 'memory-match'
  | 'music-trivia'
  | 'big-movement'
  | 'pattern-castle'

export interface Room {
  id: RoomId
  mode: Mode
  title: string
  tagline: string
  /** Large emoji used on doors and badges. */
  icon: string
  /** Door panel colors. */
  from: string
  to: string
  /** Included with the $2.98 Demo Adventure. */
  demo: boolean
  /** Bonus doors open once the explorer has this many stars in the mode. */
  unlockStars?: number
  movement?: boolean
  badge: string
  intro: string
}

export const ROOMS: Room[] = [
  {
    id: 'color-garden',
    mode: 'little',
    title: 'Color Garden',
    tagline: 'Touch the balloons and hear their colors',
    icon: '🎈',
    from: '#ff6fae',
    to: '#ffb3d4',
    demo: true,
    badge: 'Rainbow Spotter',
    intro: 'Hello, little explorer! Let’s touch the floaty balloons together.',
  },
  {
    id: 'animal-friends',
    mode: 'little',
    title: 'Animal Friends',
    tagline: 'Meow, woof, quack and moo!',
    icon: '🐱',
    from: '#ffc93c',
    to: '#ffe58a',
    demo: true,
    badge: 'Animal Pal',
    intro: 'Our animal friends want to say hello. Tap them to hear their voices!',
  },
  {
    id: 'shape-parade',
    mode: 'little',
    title: 'Shape Parade',
    tagline: 'Circles, squares, hearts and stars',
    icon: '⭐',
    from: '#38c97a',
    to: '#9ff0bf',
    demo: false,
    badge: 'Shape Finder',
    intro: 'The shapes are having a parade! Tap one and watch it twirl.',
  },
  {
    id: 'sparkle-music',
    mode: 'little',
    title: 'Sparkle Music',
    tagline: 'A playful clarinet song',
    icon: '🎵',
    from: '#7b3fe4',
    to: '#b892ff',
    demo: false,
    badge: 'Little Music Maker',
    intro: 'Listen! Clara the clarinet has a happy little song for you.',
  },
  {
    id: 'little-movement',
    mode: 'little',
    title: 'Movement Magic Ladder',
    tagline: 'Wiggle, scoot and stretch with a grown-up',
    icon: '🪜',
    from: '#3ec5ff',
    to: '#a6e6ff',
    demo: true,
    movement: true,
    badge: 'Wiggle Star',
    intro: 'Grown-ups, find a soft, open space. We’ll move together, one step at a time.',
  },
  {
    id: 'laundry-day',
    mode: 'big',
    title: 'Laundry Day',
    tagline: 'Sort, wash, and fold like a pro',
    icon: '🧺',
    from: '#ff6fae',
    to: '#ffb3d4',
    demo: true,
    badge: 'Laundry Hero',
    intro: 'The laundry basket is overflowing! Sort each piece into the right load.',
  },
  {
    id: 'music-trivia',
    mode: 'big',
    title: 'Music Trivia',
    tagline: 'Which instrument did you hear?',
    icon: '🎷',
    from: '#7b3fe4',
    to: '#b892ff',
    demo: true,
    badge: 'Sharp Ears',
    intro: 'Listen closely. Can you name each instrument by its sound?',
  },
  {
    id: 'clean-salon',
    mode: 'big',
    title: 'Clean Salon Challenge',
    tagline: 'Spot what needs a little care',
    icon: '💈',
    from: '#ffc93c',
    to: '#ffe58a',
    demo: false,
    badge: 'Salon Inspector',
    intro: 'Be a junior salon inspector. Get the salon sparkling clean before the first guest!',
  },
  {
    id: 'memory-match',
    mode: 'big',
    title: 'Memory Match',
    tagline: 'Flip, remember, and match',
    icon: '🃏',
    from: '#38c97a',
    to: '#9ff0bf',
    demo: false,
    badge: 'Memory Master',
    intro: 'The styling tools are hiding in pairs. Find every match!',
  },
  {
    id: 'big-movement',
    mode: 'big',
    title: 'Movement Magic Ladder',
    tagline: 'Climb the ladder with movement combos',
    icon: '🪜',
    from: '#3ec5ff',
    to: '#a6e6ff',
    demo: true,
    movement: true,
    badge: 'Ladder Champion',
    intro: 'Step back from the screen into a clear space. Each rung is a new move!',
  },
  {
    id: 'pattern-castle',
    mode: 'big',
    title: 'Pattern Castle',
    tagline: 'Bonus door: what comes next?',
    icon: '🏰',
    from: '#ff8a3d',
    to: '#ffc59b',
    demo: false,
    unlockStars: 6,
    badge: 'Pattern Royalty',
    intro: 'You unlocked the secret castle! Finish each sparkly pattern.',
  },
]

export const roomsFor = (mode: Mode) => ROOMS.filter((r) => r.mode === mode)
export const getRoom = (id: string) => ROOMS.find((r) => r.id === id)

export function modeStars(progress: Progress, mode: Mode) {
  return roomsFor(mode).reduce(
    (sum, r) => sum + (progress.rooms[r.id]?.stars ?? 0),
    0,
  )
}

export type DoorState = 'open' | 'locked-tier' | 'locked-stars' | 'hidden-movement'

export function doorState(
  room: Room,
  tier: Tier,
  progress: Progress,
  movementEnabled: boolean,
): DoorState {
  if (room.movement && !movementEnabled) return 'hidden-movement'
  if (tier === 'none') return 'locked-tier'
  if (tier === 'demo' && !room.demo) return 'locked-tier'
  if (room.unlockStars && modeStars(progress, room.mode) < room.unlockStars)
    return 'locked-stars'
  return 'open'
}

/** True once every demo room of a mode has been completed. */
export function demoFinished(progress: Progress, mode: Mode, movementEnabled: boolean) {
  return roomsFor(mode)
    .filter((r) => r.demo && (movementEnabled || !r.movement))
    .every((r) => progress.rooms[r.id])
}

export interface Accessory {
  id: string
  name: string
  emoji: string
  stars: number
}

export const ACCESSORIES: Accessory[] = [
  { id: 'bow', name: 'Bubblegum Bow', emoji: '🎀', stars: 2 },
  { id: 'sunglasses', name: 'Sunny Shades', emoji: '🕶️', stars: 5 },
  { id: 'headphones', name: 'Music Headphones', emoji: '🎧', stars: 8 },
  { id: 'crown', name: 'Sparkle Crown', emoji: '👑', stars: 12 },
  { id: 'wand', name: 'Star Wand', emoji: '🪄', stars: 16 },
  { id: 'cape', name: 'Explorer Cape', emoji: '🦸', stars: 22 },
]

export function unlockedAccessories(progress: Progress) {
  const stars = totalStars(progress)
  return ACCESSORIES.filter((a) => stars >= a.stars)
}

export interface Movement {
  id: string
  name: string
  cue: string
  /** Safe for caregiver-guided toddler play. */
  toddler: boolean
  /** Small text shown for grown-ups. */
  safety?: string
}

export const MOVEMENTS: Movement[] = [
  { id: 'walk', name: 'Walk', cue: 'Walk around the play area', toddler: true },
  { id: 'arms', name: 'Arm Circles', cue: 'Stretch and circle your arms', toddler: true },
  { id: 'bend', name: 'Bend', cue: 'Bend forward gently', toddler: true },
  { id: 'squat', name: 'Squat', cue: 'Bend your knees into a squat', toddler: true },
  { id: 'kneel', name: 'Kneel', cue: 'Kneel down and reach up high', toddler: true },
  { id: 'crouch', name: 'Crouch', cue: 'Lower your body down small', toddler: false },
  { id: 'scoot', name: 'Scoot', cue: 'Scoot along a safe surface', toddler: true },
  { id: 'roll', name: 'Roll', cue: 'Roll gently on a soft floor mat', toddler: true, safety: 'Use a soft mat and clear space.' },
  { id: 'lie', name: 'Lie Down', cue: 'Stretch out long on the floor', toddler: true },
  { id: 'jump', name: 'Jump', cue: 'Jump in place', toddler: false },
  { id: 'hop', name: 'Hop', cue: 'Hop on one foot, hold a hand if needed', toddler: false, safety: 'Offer a hand or wall for balance.' },
  { id: 'run', name: 'Run', cue: 'Run safely in an open space', toddler: false, safety: 'Only in a clear, open space.' },
]

export const COLORS = [
  { name: 'Red', hex: '#ff4b5c' },
  { name: 'Orange', hex: '#ff8a3d' },
  { name: 'Yellow', hex: '#ffd23f' },
  { name: 'Green', hex: '#2ed47a' },
  { name: 'Blue', hex: '#3e8bff' },
  { name: 'Purple', hex: '#8a4fff' },
]
