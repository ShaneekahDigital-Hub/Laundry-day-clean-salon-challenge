/**
 * Tiny Web Audio synth for every sound in the game. Sounds are generated on
 * the fly, so nothing needs to download before play starts.
 */

export interface AudioPrefs {
  volume: number
  muted: boolean
  sfx: boolean
  music: boolean
  voice: boolean
}

export type Instrument =
  | 'clarinet'
  | 'drum'
  | 'piano'
  | 'violin'
  | 'trumpet'
  | 'xylophone'

const NOTE: Record<string, number> = {
  C4: 261.63, D4: 293.66, E4: 329.63, F4: 349.23, G4: 392.0, A4: 440.0,
  B4: 493.88, C5: 523.25, D5: 587.33, E5: 659.25, F5: 698.46, G5: 783.99,
  A5: 880.0, C6: 1046.5,
}

// A bouncy little clarinet tune: [note, beats]
const CLARINET_SONG: [string, number][] = [
  ['G4', 0.5], ['C5', 0.5], ['E5', 0.5], ['G5', 1], ['E5', 0.5], ['F5', 0.5],
  ['D5', 1], ['B4', 0.5], ['C5', 0.5], ['D5', 0.5], ['E5', 0.5], ['C5', 1.5],
]
const SHORT_PHRASE: [string, number][] = [
  ['C5', 0.5], ['E5', 0.5], ['G5', 0.5], ['E5', 0.5], ['C5', 1],
]

class SoundEngine {
  private ctx: AudioContext | null = null
  private master: GainNode | null = null
  private noiseBuffer: AudioBuffer | null = null
  private prefs: AudioPrefs = {
    volume: 0.7,
    muted: false,
    sfx: true,
    music: true,
    voice: true,
  }
  private musicTimer: number | null = null

  configure(prefs: AudioPrefs) {
    this.prefs = prefs
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(
        prefs.muted ? 0 : prefs.volume,
        this.ctx.currentTime,
        0.03,
      )
    }
    if (prefs.muted || !prefs.voice) this.stopSpeech()
  }

  private ensure(): AudioContext | null {
    if (typeof window === 'undefined') return null
    if (!this.ctx) {
      const Ctor =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext })
          .webkitAudioContext
      if (!Ctor) return null
      this.ctx = new Ctor()
      this.master = this.ctx.createGain()
      this.master.gain.value = this.prefs.muted ? 0 : this.prefs.volume
      // Soft limiter keeps stacked sounds gentle on little ears.
      const comp = this.ctx.createDynamicsCompressor()
      comp.threshold.value = -14
      comp.ratio.value = 6
      this.master.connect(comp).connect(this.ctx.destination)
    }
    if (this.ctx.state === 'suspended') void this.ctx.resume()
    return this.ctx
  }

  private canPlay(channel: 'sfx' | 'music') {
    if (this.prefs.muted || this.prefs.volume <= 0) return null
    if (!this.prefs[channel]) return null
    return this.ensure()
  }

  private noise(ctx: AudioContext) {
    if (!this.noiseBuffer) {
      const buf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate)
      const data = buf.getChannelData(0)
      for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1
      this.noiseBuffer = buf
    }
    const src = ctx.createBufferSource()
    src.buffer = this.noiseBuffer
    return src
  }

  private env(ctx: AudioContext, t: number, peak: number, attack: number, release: number) {
    const g = ctx.createGain()
    g.gain.setValueAtTime(0.0001, t)
    g.gain.exponentialRampToValueAtTime(peak, t + attack)
    g.gain.exponentialRampToValueAtTime(0.0001, t + attack + release)
    g.connect(this.master!)
    return g
  }

  private tone(
    ctx: AudioContext,
    type: OscillatorType,
    freq: number,
    t: number,
    dur: number,
    peak = 0.25,
    attack = 0.01,
  ) {
    const o = ctx.createOscillator()
    o.type = type
    o.frequency.setValueAtTime(freq, t)
    o.connect(this.env(ctx, t, peak, attack, dur))
    o.start(t)
    o.stop(t + attack + dur + 0.05)
    return o
  }

  // ---------- Feedback sounds ----------

  pop() {
    const ctx = this.canPlay('sfx')
    if (!ctx) return
    const t = ctx.currentTime
    const o = this.tone(ctx, 'sine', 660, t, 0.12, 0.3)
    o.frequency.exponentialRampToValueAtTime(260, t + 0.12)
  }

  sparkle() {
    const ctx = this.canPlay('sfx')
    if (!ctx) return
    const t = ctx.currentTime
    ;[1568, 2093, 2637, 3136].forEach((f, i) =>
      this.tone(ctx, 'triangle', f, t + i * 0.055, 0.25, 0.09),
    )
  }

  note(index: number) {
    const ctx = this.canPlay('sfx')
    if (!ctx) return
    const scale = ['C5', 'D5', 'E5', 'G5', 'A5', 'C6']
    const f = NOTE[scale[((index % scale.length) + scale.length) % scale.length]]
    this.tone(ctx, 'triangle', f, ctx.currentTime, 0.45, 0.22)
    this.tone(ctx, 'sine', f * 2, ctx.currentTime, 0.25, 0.05)
  }

  gentleNo() {
    const ctx = this.canPlay('sfx')
    if (!ctx) return
    const t = ctx.currentTime
    this.tone(ctx, 'sine', 392, t, 0.18, 0.15)
    this.tone(ctx, 'sine', 330, t + 0.16, 0.25, 0.15)
  }

  success() {
    const ctx = this.canPlay('sfx')
    if (!ctx) return
    const t = ctx.currentTime
    ;['C5', 'E5', 'G5'].forEach((n, i) =>
      this.tone(ctx, 'triangle', NOTE[n], t + i * 0.09, 0.3, 0.2),
    )
  }

  celebrate() {
    const ctx = this.canPlay('sfx')
    if (!ctx) return
    const t = ctx.currentTime
    const seq = ['C5', 'E5', 'G5', 'C6', 'G5', 'C6']
    seq.forEach((n, i) => {
      this.tone(ctx, 'triangle', NOTE[n], t + i * 0.12, 0.35, 0.2)
      this.tone(ctx, 'sine', NOTE[n] / 2, t + i * 0.12, 0.3, 0.08)
    })
    window.setTimeout(() => this.sparkle(), 750)
  }

  doorOpen() {
    const ctx = this.canPlay('sfx')
    if (!ctx) return
    const t = ctx.currentTime
    const o = this.tone(ctx, 'sine', 300, t, 0.6, 0.18, 0.05)
    o.frequency.exponentialRampToValueAtTime(900, t + 0.6)
    window.setTimeout(() => this.sparkle(), 350)
  }

  // ---------- Animals ----------

  meow() {
    const ctx = this.canPlay('sfx')
    if (!ctx) return
    const t = ctx.currentTime
    const o = ctx.createOscillator()
    o.type = 'sawtooth'
    o.frequency.setValueAtTime(520, t)
    o.frequency.exponentialRampToValueAtTime(820, t + 0.18)
    o.frequency.exponentialRampToValueAtTime(430, t + 0.6)
    const f = ctx.createBiquadFilter()
    f.type = 'bandpass'
    f.Q.value = 3
    f.frequency.setValueAtTime(900, t)
    f.frequency.linearRampToValueAtTime(1800, t + 0.2)
    f.frequency.linearRampToValueAtTime(800, t + 0.6)
    o.connect(f).connect(this.env(ctx, t, 0.5, 0.06, 0.6))
    o.start(t)
    o.stop(t + 0.75)
  }

  bark() {
    const ctx = this.canPlay('sfx')
    if (!ctx) return
    const t0 = ctx.currentTime
    ;[0, 0.28].forEach((d) => {
      const t = t0 + d
      const o = ctx.createOscillator()
      o.type = 'square'
      o.frequency.setValueAtTime(330, t)
      o.frequency.exponentialRampToValueAtTime(140, t + 0.14)
      const f = ctx.createBiquadFilter()
      f.type = 'lowpass'
      f.frequency.value = 1200
      o.connect(f).connect(this.env(ctx, t, 0.35, 0.01, 0.15))
      o.start(t)
      o.stop(t + 0.2)
      const n = this.noise(ctx)
      const nf = ctx.createBiquadFilter()
      nf.type = 'bandpass'
      nf.frequency.value = 900
      n.connect(nf).connect(this.env(ctx, t, 0.25, 0.005, 0.08))
      n.start(t)
      n.stop(t + 0.1)
    })
  }

  quack() {
    const ctx = this.canPlay('sfx')
    if (!ctx) return
    const t0 = ctx.currentTime
    ;[0, 0.22].forEach((d) => {
      const t = t0 + d
      const o = ctx.createOscillator()
      o.type = 'sawtooth'
      o.frequency.setValueAtTime(440, t)
      o.frequency.linearRampToValueAtTime(320, t + 0.15)
      const f = ctx.createBiquadFilter()
      f.type = 'bandpass'
      f.frequency.value = 1400
      f.Q.value = 6
      o.connect(f).connect(this.env(ctx, t, 0.6, 0.01, 0.16))
      o.start(t)
      o.stop(t + 0.2)
    })
  }

  moo() {
    const ctx = this.canPlay('sfx')
    if (!ctx) return
    const t = ctx.currentTime
    const o = ctx.createOscillator()
    o.type = 'sawtooth'
    o.frequency.setValueAtTime(150, t)
    o.frequency.linearRampToValueAtTime(190, t + 0.3)
    o.frequency.linearRampToValueAtTime(130, t + 1.1)
    const f = ctx.createBiquadFilter()
    f.type = 'lowpass'
    f.frequency.setValueAtTime(400, t)
    f.frequency.linearRampToValueAtTime(900, t + 0.35)
    f.frequency.linearRampToValueAtTime(350, t + 1.1)
    o.connect(f).connect(this.env(ctx, t, 0.5, 0.15, 1))
    o.start(t)
    o.stop(t + 1.25)
  }

  tweet() {
    const ctx = this.canPlay('sfx')
    if (!ctx) return
    const t0 = ctx.currentTime
    ;[0, 0.14, 0.28].forEach((d) => {
      const t = t0 + d
      const o = this.tone(ctx, 'sine', 2400, t, 0.1, 0.18)
      o.frequency.exponentialRampToValueAtTime(3600, t + 0.06)
      o.frequency.exponentialRampToValueAtTime(2600, t + 0.1)
    })
  }

  // ---------- Instruments ----------

  private instrumentNote(inst: Instrument, freq: number, t: number, dur: number, channel: 'sfx' | 'music') {
    const ctx = this.canPlay(channel)
    if (!ctx) return
    switch (inst) {
      case 'clarinet': {
        // Odd harmonics + a soft filter = woody clarinet tone.
        const o = ctx.createOscillator()
        o.type = 'square'
        o.frequency.setValueAtTime(freq, t)
        const vib = ctx.createOscillator()
        const vibGain = ctx.createGain()
        vib.frequency.value = 5
        vibGain.gain.value = freq * 0.006
        vib.connect(vibGain).connect(o.frequency)
        const f = ctx.createBiquadFilter()
        f.type = 'lowpass'
        f.frequency.value = freq * 3.2
        f.Q.value = 0.7
        const g = ctx.createGain()
        g.gain.setValueAtTime(0.0001, t)
        g.gain.exponentialRampToValueAtTime(0.16, t + 0.04)
        g.gain.setValueAtTime(0.14, t + Math.max(0.05, dur - 0.06))
        g.gain.exponentialRampToValueAtTime(0.0001, t + dur + 0.05)
        o.connect(f).connect(g).connect(this.master!)
        o.start(t)
        vib.start(t)
        o.stop(t + dur + 0.1)
        vib.stop(t + dur + 0.1)
        break
      }
      case 'piano': {
        this.tone(ctx, 'triangle', freq, t, dur + 0.6, 0.25, 0.005)
        this.tone(ctx, 'sine', freq * 2, t, dur * 0.6, 0.08, 0.005)
        this.tone(ctx, 'sine', freq * 3, t, dur * 0.3, 0.03, 0.005)
        break
      }
      case 'xylophone': {
        this.tone(ctx, 'sine', freq * 2, t, 0.35, 0.3, 0.002)
        this.tone(ctx, 'sine', freq * 8, t, 0.06, 0.05, 0.002)
        break
      }
      case 'violin': {
        const o = ctx.createOscillator()
        o.type = 'sawtooth'
        o.frequency.setValueAtTime(freq, t)
        const vib = ctx.createOscillator()
        const vg = ctx.createGain()
        vib.frequency.value = 6
        vg.gain.value = freq * 0.012
        vib.connect(vg).connect(o.frequency)
        const f = ctx.createBiquadFilter()
        f.type = 'lowpass'
        f.frequency.value = 2600
        o.connect(f).connect(this.env(ctx, t, 0.12, 0.12, dur))
        o.start(t)
        vib.start(t)
        o.stop(t + dur + 0.2)
        vib.stop(t + dur + 0.2)
        break
      }
      case 'trumpet': {
        const o = ctx.createOscillator()
        o.type = 'sawtooth'
        o.frequency.setValueAtTime(freq * 0.98, t)
        o.frequency.linearRampToValueAtTime(freq, t + 0.04)
        const f = ctx.createBiquadFilter()
        f.type = 'lowpass'
        f.frequency.setValueAtTime(800, t)
        f.frequency.linearRampToValueAtTime(3200, t + 0.06)
        o.connect(f).connect(this.env(ctx, t, 0.16, 0.03, dur))
        o.start(t)
        o.stop(t + dur + 0.1)
        break
      }
      case 'drum': {
        const o = ctx.createOscillator()
        o.type = 'sine'
        o.frequency.setValueAtTime(160, t)
        o.frequency.exponentialRampToValueAtTime(50, t + 0.25)
        o.connect(this.env(ctx, t, 0.7, 0.003, 0.3))
        o.start(t)
        o.stop(t + 0.35)
        const n = this.noise(ctx)
        const nf = ctx.createBiquadFilter()
        nf.type = 'highpass'
        nf.frequency.value = 1800
        n.connect(nf).connect(this.env(ctx, t, 0.12, 0.002, 0.08))
        n.start(t)
        n.stop(t + 0.1)
        break
      }
    }
  }

  /** Short recognizable phrase, used by music trivia and instrument buttons. */
  playInstrument(inst: Instrument) {
    const ctx = this.canPlay('sfx')
    if (!ctx) return 0
    const t = ctx.currentTime + 0.05
    const beat = 0.28
    if (inst === 'drum') {
      ;[0, 1, 2, 2.5, 3].forEach((b) => this.instrumentNote('drum', 0, t + b * beat, 0.2, 'sfx'))
      return 1400
    }
    let at = t
    for (const [n, beats] of SHORT_PHRASE) {
      this.instrumentNote(inst, NOTE[n] / (inst === 'clarinet' || inst === 'trumpet' ? 2 : 1), at, beats * beat * 0.95, 'sfx')
      at += beats * beat
    }
    return Math.round((at - t) * 1000)
  }

  /** The featured clarinet melody. Returns its length in ms. */
  playClarinetSong(onNote?: (i: number) => void) {
    const ctx = this.canPlay('music')
    if (!ctx) return 0
    this.stopMusic()
    const beat = 0.34
    let at = ctx.currentTime + 0.05
    const timers: number[] = []
    CLARINET_SONG.forEach(([n, beats], i) => {
      this.instrumentNote('clarinet', NOTE[n] / 2, at, beats * beat * 0.92, 'music')
      if (onNote) {
        const delay = (at - ctx.currentTime) * 1000
        timers.push(window.setTimeout(() => onNote(i), delay))
      }
      at += beats * beat
    })
    const total = (at - ctx.currentTime) * 1000
    this.musicTimer = window.setTimeout(() => (this.musicTimer = null), total)
    return Math.round(total)
  }

  stopMusic() {
    if (this.musicTimer) window.clearTimeout(this.musicTimer)
    this.musicTimer = null
  }

  // ---------- Voice ----------

  say(text: string, opts: { rate?: number; pitch?: number } = {}) {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return
    if (this.prefs.muted || !this.prefs.voice || this.prefs.volume <= 0) return
    window.speechSynthesis.cancel()
    const u = new SpeechSynthesisUtterance(text)
    u.rate = opts.rate ?? 0.95
    u.pitch = opts.pitch ?? 1.25
    u.volume = Math.min(1, this.prefs.volume + 0.15)
    window.speechSynthesis.speak(u)
  }

  stopSpeech() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window)
      window.speechSynthesis.cancel()
  }
}

export const sound = new SoundEngine()
