import { z } from 'zod'

export const roomResultSchema = z.object({
  stars: z.number().int().min(0).max(3),
  times: z.number().int().min(0).max(100000),
  completedAt: z.string().max(40),
})

export const progressSchema = z.object({
  version: z.literal(1),
  explorerName: z.string().trim().max(24),
  rooms: z.record(z.string().max(40), roomResultSchema),
  equipped: z.array(z.string().max(40)).max(12),
  updatedAt: z.string().max(40),
})

export type RoomResult = z.infer<typeof roomResultSchema>
export type Progress = z.infer<typeof progressSchema>

export function emptyProgress(): Progress {
  return {
    version: 1,
    explorerName: '',
    rooms: {},
    equipped: [],
    updatedAt: new Date(0).toISOString(),
  }
}

export function totalStars(progress: Progress) {
  return Object.values(progress.rooms).reduce((sum, r) => sum + r.stars, 0)
}

/** Combines two saves without losing anything a child has earned. */
export function mergeProgress(a: Progress, b: Progress): Progress {
  const newer = a.updatedAt >= b.updatedAt ? a : b
  const rooms: Progress['rooms'] = { ...a.rooms }
  for (const [id, result] of Object.entries(b.rooms)) {
    const existing = rooms[id]
    rooms[id] = existing
      ? {
          stars: Math.max(existing.stars, result.stars),
          times: Math.max(existing.times, result.times),
          completedAt:
            existing.completedAt < result.completedAt
              ? existing.completedAt
              : result.completedAt,
        }
      : result
  }
  return {
    version: 1,
    explorerName: newer.explorerName || a.explorerName || b.explorerName,
    rooms,
    equipped: newer.equipped,
    updatedAt: newer.updatedAt,
  }
}
