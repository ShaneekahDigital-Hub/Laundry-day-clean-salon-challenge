// Product pages on the Square Online store at rbvendorsconcierge.com.
// Replace these with the exact product links once they're published.
const STORE = 'https://www.rbvendorsconcierge.com'

export const PRODUCTS = {
  demo: {
    name: 'Demo Adventure',
    price: '$2.98',
    kicker: 'Try before upgrading',
    checkoutUrl: import.meta.env.VITE_DEMO_CHECKOUT_URL || STORE,
    blurb:
      'A paid introductory experience: explore the game, enter selected rooms, touch interactive objects, hear sounds, and complete real sample activities.',
    bestFor:
      'Families who want a real taste of the adventure before committing.',
    details: [
      'The Demo Adventure is a genuine, playable slice of the Learning Collection, not a preview video. Your explorer walks into the magical hallway, opens real doors, and plays complete rooms from start to finish.',
      'Both age modes are included, so you can see how gentle, grown-up guided play for ages 0–2 differs from the puzzles and trivia made for ages 6–8. Stars, badges, and progress earned in the demo are kept if you later upgrade.',
    ],
    includes: [
      'Little Explorers: Color Garden & Animal Friends',
      'Big Explorers: Laundry Day & Music Trivia',
      'A starter Movement Magic Ladder for each age',
      'Stars, badges, and saved progress',
    ],
  },
  full: {
    name: 'Full Learning Collection',
    price: '$24.99',
    kicker: 'Complete experience',
    checkoutUrl: import.meta.env.VITE_FULL_CHECKOUT_URL || STORE,
    blurb:
      'Unlock the complete adventure collection: every room, interactive object, age-appropriate challenge, movement activity, music trivia, and reward.',
    bestFor: 'Families ready for every door, every age mode, and every reward.',
    details: [
      'The Full Learning Collection opens every door in both magical hallways. Little Explorers discover colors, shapes, animal sounds, and a playful clarinet melody, while Big Explorers sort laundry, inspect a sparkling salon, match memory cards, and answer music trivia.',
      'It also includes the complete 12-rung Movement Magic Ladder, the secret Pattern Castle bonus door, printable room certificates, and every character accessory. Access is ongoing, so children can come back and replay any room on another day.',
    ],
    includes: [
      'All 11 rooms across both age modes',
      'Shape Parade, Sparkle Music, Clean Salon & Memory Match',
      'The full 12-rung Movement Magic Ladder',
      'Secret bonus door, certificates & every accessory',
    ],
  },
} as const

/** Features that come with every purchase, shown on the collection page. */
export const EVERY_PURCHASE = [
  'Plays in the browser on phones, tablets, and computers, with nothing to download',
  'Touch, click, and keyboard-friendly controls',
  'Two separate age modes with their own hallway and difficulty',
  'Built-in sounds: animal voices, clarinet music, sparkles, and spoken names',
  'Grown-up settings for volume, mute, music, voice, calm motion, and play-time breaks',
  'Progress saved on the device and to your family’s purchase',
]

export const CREDIT_NOTE =
  'The $2.98 Demo Adventure and the $24.99 Full Learning Collection are separate purchases. The demo price is not credited toward the full collection.'
