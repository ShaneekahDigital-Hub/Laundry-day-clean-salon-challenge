CREATE TABLE "access_sessions" (
	"id" serial PRIMARY KEY,
	"token_hash" text NOT NULL UNIQUE,
	"email" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "explorer_progress" (
	"email" text PRIMARY KEY,
	"progress" jsonb NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "purchases" (
	"id" serial PRIMARY KEY,
	"order_ref" text NOT NULL UNIQUE,
	"receipt_ref" text,
	"email" text NOT NULL,
	"tier" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "access_sessions_email_idx" ON "access_sessions" ("email");--> statement-breakpoint
CREATE INDEX "purchases_email_idx" ON "purchases" ("email");--> statement-breakpoint
CREATE INDEX "purchases_receipt_idx" ON "purchases" ("receipt_ref");