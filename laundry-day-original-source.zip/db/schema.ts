import {
  index,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
} from 'drizzle-orm/pg-core'

// One row per verified order recorded from the rbvendorsconcierge.com checkout.
export const purchases = pgTable(
  'purchases',
  {
    id: serial().primaryKey(),
    orderRef: text('order_ref').notNull().unique(),
    // Square receipt number, so families can unlock with either reference.
    receiptRef: text('receipt_ref'),
    email: text().notNull(),
    tier: text().notNull(), // 'demo' | 'full'
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (t) => [
    index('purchases_email_idx').on(t.email),
    index('purchases_receipt_idx').on(t.receiptRef),
  ],
)

// Signed-in browsers. Only a SHA-256 hash of the cookie token is stored.
export const accessSessions = pgTable(
  'access_sessions',
  {
    id: serial().primaryKey(),
    tokenHash: text('token_hash').notNull().unique(),
    email: text().notNull(),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (t) => [index('access_sessions_email_idx').on(t.email)],
)

// Saved stars, badges, and accessories for a purchasing family.
export const explorerProgress = pgTable('explorer_progress', {
  email: text().primaryKey(),
  progress: jsonb().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
})
